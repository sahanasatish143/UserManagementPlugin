package com.capgemini.dac.automate.UserManagement.Validation.Service;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.dac.automate.UserManagement.Parameters;
import com.capgemini.dac.automate.UserManagement.ResultsBlock;
import com.capgemini.dac.automate.UserManagement.Exception.InvalidPluginArguments;
import com.capgemini.dac.automate.UserManagement.Validation.Fields.ValidationFields;
import com.capgemini.dac.automate.UserManagement.Validation.FieldsImplementation.ValidationFieldsImplementation;


public class ValidationServiceImp implements ValidationImpFactory {
	private Map<ParameterEnum, String> parameterValuesMap = new HashMap<ParameterEnum, String>();
	ParameterEnum params;
	public   String put(ParameterEnum key)
	{
		return parameterValuesMap.put(key, null);
	}
	
	public String get(ParameterEnum key)
	{
		return parameterValuesMap.get(key);
	}

	@SuppressWarnings({ "unlikely-arg-type", "unused" })
	@Override
	public String validateRequiredField(Map<String, Object> myMap, Map<String, String> oneEnvMap)
			throws InvalidPluginArguments {

		String ret = null;
		if (!parameterValuesMap.keySet().contains(myMap.keySet())|| 
				!parameterValuesMap.keySet().contains(oneEnvMap.keySet())) {
			myMap.remove(parameterValuesMap.keySet());
			ret = myMap.toString();
		}

		return ret;
	}

	public String toString() {
		return parameterValuesMap.toString();
	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public boolean validateFormat(Map<String, Object> myMap, Map<String, String> oneEnvMap)
			throws InvalidPluginArguments {

		ValidationFieldsImplementation dao = new ValidationFieldsImplementation();
		List<ValidationFields> apiFields = new ArrayList<ValidationFields>();
		apiFields = dao.parseRequiredFields();
		System.out.println(parameterValuesMap.get("Email"));
		System.out.println(parameterValuesMap.get("Email"));
		Iterator<ValidationFields> i = apiFields.iterator();
		while (i.hasNext()) {
			ValidationFields obj = i.next();

			if (obj.getFormat().isEmpty()) {

				return false;
			} else if (Pattern.matches(obj.getFormat(), parameterValuesMap.get("Email"))
					&& Pattern.matches(obj.getFormat(), parameterValuesMap.get("EndDate"))
					&& Pattern.matches(obj.getFormat(), parameterValuesMap.get("StartDate"))) {
				
				return true;
			}
		}
		return false;
	}

  public ResultsBlock validateParametersAndSetDefaults(Parameters parameters)
  {
    // Check for missing required fields.
    ValidationFieldsImplementation dao = new ValidationFieldsImplementation();
    ResultsBlock result = new ResultsBlock();
    ArrayList<String> requiredFields = dao.getRequiredFields();
    for(String name: requiredFields)
    {
      if(!parameters.hasField(name))
      {
        result.setErrors(true);
        result.addMessage("Error", "Missing required field" + name);
      } 
    }
    // Check validity of all defined fields.
    Enumeration<String> fields = parameters.fieldNames();
    while (fields.hasMoreElements()) {
      String key = fields.nextElement();
      if(dao.isFieldDefined(key))
      {
        if(!dao.isFieldValueValid(key, parameters.getField(key)))
        {
          result.setErrors(true);
          result.addMessage("Error", "Field \"" + key + "\" has a bad value of \"" 
                                                + parameters.getField(key) 
                                                + ". The correct format is \"" 
                                                + dao.getFriendlyFormat() + "\"");
        }
        else
        {
          result.setWarning(true);
          result.addMessage("Warning", "Found unknown field \"" + key + "\". Ignoring the field.");
        }
      }
    }
    // Set defaults to optional fields missing value with defined defaults.
    ArrayList<String> defaultFields = dao.getDefualtFields();
    for(String name: defaultFields) 
    {
      if(!parameters.hasField(name) || parameters.getField(name).equals(""))
      {
        parameters.addField(name, dao.getDefaultValue(name));
        result.setWarning(true);
        result.addMessage("Warning", "Field \"" + name + "\" has empty value. Set to defualt value of \"" + parameters.getField(name) + "\"");
      } 
    }
    return result;
  }
}