package com.capgemini.dac.automate.UserManagement.Validation.FieldsImplementation;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.dac.automate.UserManagement.Validation.Fields.ValidationFields;

public class ValidationFieldsImplementation {

	

	public List<ValidationFields> parseRequiredFields() {
		int count=0;
		List<ValidationFields> paramList=new ArrayList<ValidationFields>();
		ValidationFields apiFields=new ValidationFields();
		apiFields.setName("Email");
		apiFields.setFieldType("String");
		apiFields.setRequired(true);
		apiFields.setFormat("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$");
		apiFields.setdateFormat("dd-mm-yyyy hh:mm:ss");
		paramList.add(apiFields);
		count++;
		
	
	if(count==0)
	{
		return null;
	}
	else
	{
		return paramList;
	}
	
}

  public String getFriendlyFormat()
  {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean isFieldValueValid(String key, String field)
  {
    // TODO Auto-generated method stub
    return false;
  }

  public boolean isFieldDefined(String key)
  {
    // TODO Auto-generated method stub
    return false;
  }

  public ArrayList<String> getRequiredFields()
  {
    // TODO Auto-generated method stub
    return null;
  }

  public ArrayList<String> getDefualtFields()
  {
    // TODO Auto-generated method stub
    return null;
  }

  public String getDefaultValue(String name)
  {
    // TODO Auto-generated method stub
    return null;
  }
}