/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.UserManagement;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.capgemini.dac.automate.UserManagement.Exception.InvalidPluginArguments;
import com.capgemini.dac.automate.UserManagement.Validation.Fields.ValidationFields;
import com.capgemini.dac.automate.UserManagement.Validation.Service.ValidationServiceImp;
import com.capgemini.dac.automate.UserManagement.Validation.Service.ParameterEnum;
import com.capgemini.dac.automate.UserManagement.Validation.Service.ParameterValues;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

/**
 * The Class MainResource. This class represents the main class of the web
 * service. In this class we accept web request as input parameters and we
 * invoke different plugins (functionality) in the SAP/oracle system.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 */

@Path("/usermanagement")
public class MainResource
{

  /** The Constant CONFIGURATION_FILE_PATH. */
  private static final String CONFIGURATION_FILE_PATH = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\userProvisioning.properties";

  /** The plugin manager. */
  private PluginManager pluginManager;
  private Logger logger = Logger.getLogger(MainResource.class.getName());
  private ValidationServiceImp service = new ValidationServiceImp();
  private CentralServices centralservices = new CentralServices(this);

  /** The user id. */
  static String userId;

  /** The user name. */
  static String userName;

  /** The req password. */
  static String reqPassword;

  /** The random generated password. */
  static String generatedPassword;

  /** The from date. */
  static String name;

  /** The response from plugin. */
  static String responsePlugin;

  /** The new password */
  static String newPassword;

  /** The e-mail. */
  static String eMail;

  static String environment;

  /** The hash map value. */
  static HashMap<String, String> map = new HashMap<String, String>();
  HashMap<String, String> inputs = null;

  static Map<String, String> gsonMap = new HashMap<String, String>();

  /** The role assigned. */
  static String roleAssigned;

  /** The json. */
  static JSONObject json = new JSONObject();

  /**
   * Default constructor. Used for logger initializing and to generate logger
   * files and Instantiates attributes. code pull changes
   * 
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public MainResource() throws IOException
  {
     try
    {
      InputStream inputStream = Thread.currentThread().getContextClassLoader()
          .getResourceAsStream("logging.properties");
      LogManager.getLogManager().readConfiguration(inputStream);
      logger.info("Initializing logger"); 
      centralservices.registerLogger(logger);
      
    }
    catch (Exception e)
    {
      logger.info("ERROR: While initializing logger");
      logger.severe("ERROR: While initializing logger");
      e.printStackTrace();
    }
    // }

    Map<String, String> configuration = null;
    try
    {
      configuration = readProperties();
    }
    catch (IOException e2)
    {
      e2.printStackTrace();
      logger.severe(e2.getMessage());
    }
    String path = configuration.get("PATH_TO_PLUGIN_DIRECTORY");
    // load all plugins in plugin directory
    pluginManager = PluginManager.getInstance(path);
    centralservices.registerPluginManager(pluginManager);
    logger.info("plugin loaded");
  }

  /**
   * Read properties. read the connection properties from property file
   * 
   * @return the map
   * @throws IOException Signals that an I/O exception has occurred.
   */
  private Map<String, String> readProperties() throws IOException
  {
    Map<String, String> map = new HashMap<String, String>();

    try
    {
      Properties props = new Properties();
      FileReader fReader = null;
      fReader = new FileReader(CONFIGURATION_FILE_PATH);
      props.load(fReader);
      map.put("PATH_TO_PLUGIN_DIRECTORY", props.getProperty("PATH_TO_PLUGIN_DIRECTORY"));

    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
      logger.severe("config file not found");
    }

    return map;
  }

  enum ACTION
  {
    CREATE, UPDATE, DELETE, RESETPASSWORD, USERINFO
  };

  /**
   * User Create. if functionality is to create the user with userid,name,email
   * and generate a random password then invoke the following lines of code
   * 
   * @param incomingData the incoming data
   * @return the string
   * @throws ParseException the parse exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  @SuppressWarnings({ "unchecked", "deprecation" })
  @POST
  @Path("/user/create")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)

  public String createUser(String incomingData) throws ParseException, IOException, java.text.ParseException
  {
    Parameters parameters = new Parameters().initializeFromJSON(incomingData);
    parameters.addField("RequestID", registerRequest(ACTION.CREATE, parameters));
    ResultsBlock validation = this.service.validateParametersAndSetDefaults(parameters);
    for (String environment: parameters.getEnvironmentNames()) 
      validation.mergeResults(pluginManager.getPlugin(environment).validateParameters(parameters));
    if(!validation.hasErrors()) {
      for (String environment: parameters.getEnvironmentNames())
        validation.mergeResults(pluginManager.getPlugin(environment).createUser(parameters));
    }
    return validation.toJSONResponse();
  }

private String registerRequest(ACTION create, Parameters parameters)
  {
       return null;
  }

//	public String createUser(String incomingData) throws ParseException, IOException, java.text.ParseException {
//
//		List<String> response = new ArrayList<String>();
//		String jsonData = incomingData;
//
//		Map<String, Object> myMap = getDimJSONMap(jsonData);
//
//		ArrayList<LinkedTreeMap<String, String>> envList = (ArrayList<LinkedTreeMap<String, String>>) myMap
//				.get("Environments");
//		for (Map<String, String> oneEnvMap : envList) {
//
//			environment = oneEnvMap.get("Environment");
//
//			try {
//				ParameterValues pvals= new ParameterValues();
//				pvals.put(ParameterEnum.get("username"));
//				responsePlugin = service.validateRequiredField(myMap, oneEnvMap);
//				if (service.validateFormat(myMap, oneEnvMap) == true) {
//					responsePlugin = pluginManager.getPlugin(environment).createUser(myMap, oneEnvMap);
//					response.add(responsePlugin);
//
//				}
//				;
//
//			} catch (InvalidPluginArguments e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//				response.add("Check For Validations");
//			}
//
//		}
//		JsonParser parser = new JsonParser();
//		JsonElement jsonElement = parser.parse(response.toString());
//
//		return jsonElement.toString();
//	}

  /**
   * Change password. if functionality is to modify the password of created User
   * 
   * @param incomingData the incoming data
   * @return the string
   * @throws ParseException the parse exception
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws java.text.ParseException
   */
  @SuppressWarnings({ "unchecked", "deprecation" })
  @POST
  @Path("/resetPassword")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public String resetPassword(String incomingData) throws ParseException, IOException, java.text.ParseException
  {
    List<String> response = new ArrayList<String>();
    String jsonData = incomingData;

    Map<String, Object> myMap = getDimJSONMap(jsonData);

    ArrayList<LinkedTreeMap<String, String>> envList = (ArrayList<LinkedTreeMap<String, String>>) myMap
        .get("Environments");
    for (Map<String, String> oneEnvMap : envList)
    {

      environment = oneEnvMap.get("Environment");

      try
      {

        responsePlugin = service.validateRequiredField(myMap, oneEnvMap);
        if (service.validateFormat(myMap, oneEnvMap) == true)
        {
          responsePlugin = pluginManager.getPlugin(environment).createUser(myMap, oneEnvMap);
          response.add(responsePlugin);

        }
        ;

      }
      catch (InvalidPluginArguments e)
      {
        // TODO Auto-generated catch block
        e.printStackTrace();
        response.add("Check For Validations");
      }

    }
    JsonParser parser = new JsonParser();
    JsonElement jsonElement = parser.parse(response.toString());

    return jsonElement.toString();
  }

  /**
   * User info. To check whether user created exists and display email ID info
   * 
   * @param incomingData the incoming data
   * @return the string
   * @throws ParseException the parse exception
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws java.text.ParseException
   */
  @SuppressWarnings({ "unchecked", "deprecation" })
  @POST
  @Path("/userInfo")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public String userInfo(String incomingData) throws ParseException, IOException, java.text.ParseException
  {
    List<String> response = new ArrayList<String>();
    String jsonData = incomingData;
    Map<String, Object> myMap = getDimJSONMap(jsonData);

    ArrayList<LinkedTreeMap<String, String>> envList = (ArrayList<LinkedTreeMap<String, String>>) myMap
        .get("Environments");
    for (Map<String, String> oneEnvMap : envList)
    {

      environment = oneEnvMap.get("Environment");

      try
      {

        responsePlugin = service.validateRequiredField(myMap, oneEnvMap);
        if (service.validateFormat(myMap, oneEnvMap) == true)
        {
          responsePlugin = pluginManager.getPlugin(environment).createUser(myMap, oneEnvMap);
          response.add(responsePlugin);

        }
        ;

      }
      catch (InvalidPluginArguments e)
      {
        // TODO Auto-generated catch block
        e.printStackTrace();
        response.add("Check For Validations");
      }
    }
    JsonParser parser = new JsonParser();
    JsonElement jsonElement = parser.parse(response.toString());
    return jsonElement.toString();
  }

  /**
   * User deletion. Deletes the crested user when userId is entered
   * 
   * @param incomingData the incoming data
   * @return the string
   * @throws ParseException the parse exception
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws java.text.ParseException
   */
  @SuppressWarnings({ "unchecked", "deprecation" })
  @POST
  @Path("/userDeletion")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public String userDeletion(String incomingData) throws ParseException, IOException, java.text.ParseException
  {
    List<String> response = new ArrayList<String>();
    String jsonData = incomingData;

    Map<String, Object> myMap = getDimJSONMap(jsonData);

    ArrayList<LinkedTreeMap<String, String>> envList = (ArrayList<LinkedTreeMap<String, String>>) myMap
        .get("Environments");
    for (Map<String, String> oneEnvMap : envList)
    {

      environment = oneEnvMap.get("Environment");

      try
      {

        responsePlugin = service.validateRequiredField(myMap, oneEnvMap);
        if (service.validateFormat(myMap, oneEnvMap) == true)
        {
          responsePlugin = pluginManager.getPlugin(environment).createUser(myMap, oneEnvMap);
          response.add(responsePlugin);

        }
        ;

      }
      catch (InvalidPluginArguments e)
      {
        // TODO Auto-generated catch block
        e.printStackTrace();
        response.add("Check For Validations");
      }

    }
    JsonParser parser = new JsonParser();
    JsonElement jsonElement = parser.parse(response.toString());

    return jsonElement.toString();
  }

  /**
   * Gets the dim JSON map. this gives the nested json map for role Assignment
   * 
   * @param json the json
   * @return the dim JSON map
   */
  @SuppressWarnings("unchecked")
  private Map<String, Object> getDimJSONMap(String json)
  {
    Gson gson = new Gson();
    Map<String, Object> map = gson.fromJson(json, Map.class);
    return map;
  }

  private Parameters jsonToParameters(String json)
  {
    Parameters result = new Parameters();
    JSONObject input = new JSONObject(json);
    return result;
  }
}
