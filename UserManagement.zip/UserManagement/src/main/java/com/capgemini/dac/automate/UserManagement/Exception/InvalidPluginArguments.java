package com.capgemini.dac.automate.UserManagement.Exception;

public class InvalidPluginArguments extends Exception
{

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
