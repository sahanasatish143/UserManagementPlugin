package com.capgemini.dac.automate.UserManagement.Validation.Service;

import java.util.HashMap;
import java.util.Map;

//Enum to ensure consistency amongst the different modules (ideally)
public enum ParameterEnum {

	Environment("Environment"),
	Email("Email"),
	Id("Id"), 
	UserName("UserName"), 
	Description("Description"),
	EndDate("ValidFrom"),
	StartDate("ValidFrom");

	private String key;
	
	private static final Map<String, ParameterEnum> lookup = new HashMap<>();

	ParameterEnum(String key) {
		this.key = key.toLowerCase();
	}

	// Populate the lookup table at load time with lower case key
	static {
		for (ParameterEnum p : ParameterEnum.values()) {
			lookup.put(p.key, p);
		}
	}

	// This method can be used for reverse lookup
	public static ParameterEnum get(String key) {
		// set passed in look up key to lower case
		if (key != null)
			key = key.toLowerCase();
		return lookup.get(key);
	}

}