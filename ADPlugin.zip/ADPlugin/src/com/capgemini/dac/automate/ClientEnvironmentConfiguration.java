package com.capgemini.dac.automate;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

/**
 * @author ss143
 *
 */
public class ClientEnvironmentConfiguration {
	String name;
	String initialContextFactory;
	String user;
	String password;
	String authentication;
	String providerURL;
	ArrayList<String> searchBases;
	Logger logger;
	DirContext ctx;

	public ClientEnvironmentConfiguration() {
		this.searchBases = new ArrayList<String>();
	}

	public void addSearchBase(String searchBase) {
		searchBases.add(searchBase);

	}

	public ArrayList<String> getSearchBases() {

		return searchBases;
	}

	public Iterator<String> getSearchBaseIterator() {
		return searchBases.iterator();
	}

	public DirContext getLdapContext() {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.SECURITY_PRINCIPAL, "CN=AD Admin,CN=Users,DC=prod,DC=capgeminiautonomics,DC=com");
		env.put(Context.SECURITY_CREDENTIALS, "ADAD@daclabad01a");
		env.put(Context.PROVIDER_URL, "ldaps://DACLABAD01A:636");

		try {
			ctx = new InitialDirContext(env);
			System.out.println("Connection Successful.");
		} catch (NamingException nex) {
			System.out.println("LDAP Connection: FAILED");
			nex.printStackTrace();
		}
		return ctx;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the initialContectFactory
	 */
	public String getInitialContextFactory() {
		return this.initialContextFactory;
	}

	/**
	 * @param initialContectFactory
	 *            the initialContectFactory to set
	 */
	public void setInitialContectFactory(String initialContectFactory) {
		this.initialContextFactory = initialContectFactory;
	}

	/**
	 * @return the user
	 */
	public String getUser() {
		return this.user;
	}

	/**
	 * @param user
	 *            the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return this.password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the securityAuthentication
	 */
	public String getSecurityAuthentication() {
		return this.authentication;
	}

	/**
	 * @param securityAuthentication
	 *            the securityAuthentication to set
	 */
	public void setSecurityAuthentication(String securityAuthentication) {
		this.authentication = securityAuthentication;
	}

	/**
	 * @return the providerURL
	 */
	public String getProviderURL() {
		return this.providerURL;
	}

	/**
	 * @param providerURL
	 *            the providerURL to set
	 */
	public void setProviderURL(String providerURL) {
		this.providerURL = providerURL;
	}
}