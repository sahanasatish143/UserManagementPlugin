package com.capgemini.dac.automate;

import java.util.HashMap;

/**
 * The Class ClientContext.
 * Used to load ADClient configurations
 */
public class ClientContext {

	/** The ldap connections. */
	HashMap<String, ClientEnvironmentConfiguration> ldapConnections;

	/** The client name. */
	String clientName;

  /**
   * Gets the client name.
   *
   * @return the client name
   */
  public String getClientName() {
    return clientName;
  }

  /**
   * Sets the client name.
   *
   * @param clientName the client name
   * @return the client context
   */
  public ClientContext setClientName(String clientName) {
    this.clientName = clientName;
    return this;
  }

  /**
   * Instantiates a new client context.
   */
  public ClientContext() {
    ldapConnections = new HashMap<String, ClientEnvironmentConfiguration>();
  }

  /**
   * Gets the environment configuration.
   *
   * @param environment the environment
   * @return the environment configuration
   */
  public ClientEnvironmentConfiguration getEnvironmentConfiguration(String environment) {

    return ldapConnections.get(environment);
  }

  /**
   * Checks for environment.
   *
   * @param environment the environment
   * @return true, if successful
   */
  public boolean hasEnvironment(String environment) {
    return ldapConnections.containsKey(environment);
  }

  /**
   * Adds the environment configuration.
   *
   * @param name the name
   * @param environment the environment
   * @return the client context
   */
  public ClientContext addEnvironmentConfiguration(String name, ClientEnvironmentConfiguration environment) {
    ldapConnections.put(name, environment);
    return this;
  }
}