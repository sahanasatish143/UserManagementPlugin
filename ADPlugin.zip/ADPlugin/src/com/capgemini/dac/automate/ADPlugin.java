package com.capgemini.dac.automate;

import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.naming.InvalidNameException;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

/**
 * The Class ADPlugin. Gives user access to Active Directory
 */
public class ADPlugin implements UserManagementPlugin {

	/** The central service. */
	private CentralServices centralService = null; // for services needed by all plugins like mail or logging

	/** The version. */
	private String version;

	/** The environment tag. */
	private String environmentTag;

	/** The hash map. */
	static Map<String, String> hashMap = new HashMap<>();

	/** The Constant FILETIME_EPOCH_DIFF. */
	final static long FILETIME_EPOCH_DIFF = 11644473600000L;

	/** The clients. */
	HashMap<String, ClientContext> clients;

	/** The ldap context. */
	DirContext ldapContext;

	/** The add to response map. */
	static Map<String, String> addToResponseMap = new HashMap<>();

	/**
	 * One millisecond expressed in units of 100s of nanoseconds.
	 */
	final static long FILETIME_ONE_MILLISECOND = 10 * 1000;

	/**
	 * Instantiates a new AD plugin.
	 */
	public ADPlugin() {
		this.clients = new HashMap<String, ClientContext>();
	}

	/**
	 * Instantiates a new AD plugin.
	 *
	 * @param centralServices
	 *            the central services
	 */
	public ADPlugin(CentralServices centralServices) {
		this.clients = new HashMap<String, ClientContext>();
		this.setCentralServices(centralServices);
	}

	/**
	 * Sets the central services.
	 *
	 * @param centralServices
	 *            the new central services
	 */
	public void setCentralServices(CentralServices centralServices) {
		this.centralService = centralServices;
	}

	/**
	 * Load configuration.
	 */
	public void loadConfiguration() {
		String configurationFile = this.centralService.getConfigFilename("ActiveDirectoryPlugin");
		JSONParser jsonParser = new JSONParser();
		try {
			JSONObject jasonobj = (JSONObject) jsonParser.parse(new FileReader(configurationFile));
			JSONObject adConfig = (JSONObject) jasonobj.get("ActiveDirectoryPlugin");
			if (adConfig == null) {
				JSONObject plugins = (JSONObject) jasonobj.get("plugins");
				adConfig = (JSONObject) plugins.get("ActiveDirectoryPlugin");
			}
			this.environmentTag = (String) adConfig.get("environment_name");
			this.version = (String) adConfig.get("version");
			JSONArray clients = (JSONArray) adConfig.get("clients");
			Iterator<?> iterator = clients.iterator();
			while (iterator.hasNext()) {
				JSONObject client = (JSONObject) iterator.next();

				String filename = (String) client.get("config_file");
				if (filename != null) {
					try {
						client = (JSONObject) jsonParser.parse(new FileReader(filename));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				this.parseClientConfiguration(client);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Parses the client configuration.
	 *
	 * @param client
	 *            the client
	 */
	private void parseClientConfiguration(JSONObject client) {
		ClientContext clientContext = new ClientContext().setClientName((String) client.get("name"));
		JSONArray landscapes = (JSONArray) client.get("landscapes");
		Iterator<?> iterator = landscapes.iterator();
		while (iterator.hasNext()) {
			JSONObject jsonObject = (JSONObject) iterator.next();
			String filename = (String) jsonObject.get("config_file");
			if (filename != null) {
				JSONParser jsonParser = new JSONParser();
				try {
					jsonObject = (JSONObject) jsonParser.parse(new FileReader(filename));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			clientContext.addEnvironmentConfiguration((String) jsonObject.get("name"),
					parseClientEnvironmentConfiguration((jsonObject)));
		}
		this.clients.put(clientContext.getClientName(), clientContext);
	}

	/**
	 * Parses the client environment configuration.
	 *
	 * @param enviroconfig
	 *            the enviroconfig
	 * @return the client environment configuration
	 */
	private ClientEnvironmentConfiguration parseClientEnvironmentConfiguration(JSONObject enviroconfig) {
		ClientEnvironmentConfiguration envconfig = new ClientEnvironmentConfiguration();
		envconfig.setName((String) enviroconfig.get("name"));
		envconfig.setUser((String) enviroconfig.get("user"));
		envconfig.setPassword((String) enviroconfig.get("password"));
		envconfig.setInitialContectFactory((String) enviroconfig.get("inititial-content-factory"));
		envconfig.setProviderURL((String) enviroconfig.get("url"));
		envconfig.setSecurityAuthentication((String) enviroconfig.get("authentication"));
		JSONArray searchBases = (JSONArray) enviroconfig.get("search_bases");
		Iterator<?> iterator = searchBases.iterator();
		while (iterator.hasNext()) {
			envconfig.addSearchBase(iterator.next().toString());
		}
		return envconfig;
	}

	/*
	 * Creates user
	 * 
	 */
	@SuppressWarnings({ "unused" })
	@Override
	public ResultsBlock createUser(Parameters parameters) {
		ResultsBlock results = new ResultsBlock();
		String eMail = parameters.getField("email");
		Map<String, String> hashMap = new HashMap<>();
		StringBuffer sb = new StringBuffer();
		JSONObject jsonObj = new JSONObject();
		String password = new PasswordGenerator(5, 12, true, true, true, false, "").generate(6);
		String requestID = parameters.getField("RequestID");
		for (String client : parameters.getClients()) {
			ClientContext clientContext = clients.get(client);
			if (clientContext == null) {

				results.addInfoMessage(client, environmentTag, "client Context " + clientContext + "does not exist",
						requestID);
				return results;
			}
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {

				ClientEnvironmentConfiguration clientEnv = clientContext.getEnvironmentConfiguration(landscape);

				if (clientEnv == null) {

					results.addInfoMessage(client, environmentTag, "client environment " + clientEnv + "does not exist",
							requestID);
					return results;
				}
				clientEnv.getLdapContext();
				ArrayList<String> searchBases = clientEnv.getSearchBases();

				System.out.println(searchBases + " is the search base");
				Attributes container = new BasicAttributes();
				LdapName subjectDN = null;

				String search;

				try {
					for (int k = 0; k < searchBases.size(); k++) {
						{
							search = searchBases.get(k);
						}

						subjectDN = new LdapName(search);
						List<Rdn> rdns = subjectDN.getRdns();
						for (int i = rdns.size() - 1; i >= 0; i--) {
							final Rdn rds = rdns.get(i);
							final Attributes attributes = rds.toAttributes();
							final Attribute cn = attributes.get("dc");

							if (cn != null) {

								final String value = (String) cn.get();
								if (value != null) {

									String[] a = value.split(",");

									for (int j = 0; j < a.length; j++) {
										String segments[] = a[j].split("=");
										String last = segments[segments.length - 1];

										sb.append(last).append(".");

									}
								}
							}
						}

						String domainName = sb.toString();
						Attribute userLogonName = new BasicAttribute("userPrincipalName",
								parameters.getField("id") + "@" + domainName);
						Attribute userPassword = new BasicAttribute("userpassword", password);
						// Create the objectclass to add
						final Attribute objClasses = new BasicAttribute("objectClass");
						objClasses.add("User");
						// Assign the username, first name, and last name
						final Attribute commonName = new BasicAttribute("cn", parameters.getField("id"));
						final Attribute sAMAccountName = new BasicAttribute("sAMAccountName",
								parameters.getField("id"));
						final Attribute email = new BasicAttribute("mail", eMail);
						final Attribute firstName = new BasicAttribute("givenName", parameters.getField("first_name"));
						final Attribute uid = new BasicAttribute("uid", parameters.getField("id"));
						final Attribute surName = new BasicAttribute("sn", parameters.getField("last_name"));
						final Attribute displayName = new BasicAttribute("displayName",
								parameters.getField("first_name"));

						SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
						String dateInString = parameters.getField("end_date");
						Date date;
						date = sdf.parse(dateInString);
						final long dd = date.getTime();
						final Attribute accountExpires = new BasicAttribute("accountExpires",
								Long.toString(millisToFiletime(dd)));

						container.put(objClasses);
						container.put(commonName);
						container.put(firstName);
						container.put(email);
						container.put(uid);
						container.put(surName);
						container.put(userPassword);
						container.put(displayName);
						container.put(userLogonName);
						container.put(sAMAccountName);
						container.put(accountExpires);
						container.put(objClasses);
						container.put("cn", parameters.getField("id"));
						container.put("sAMAccountName", parameters.getField("id"));
						container.put("mail", parameters.getField("email"));
						container.put("givenName", parameters.getField("first_name"));
						container.put("uid", parameters.getField("id"));
						container.put("sn", parameters.getField("last_name"));
						container.put("displayName",
								parameters.getField("first_name") + " " + parameters.getField("last_name"));
						container.put("description", parameters.getField("department"));
						container.put("userPrincipalName", parameters.getField("id"));
						container.put(accountExpires);
						container.put(userLogonName);
						container.put(userPassword);
						String userDN = new StringBuffer().append("cn=").append(parameters.getField("id")).append(",")
								+ (search);
						clientEnv.getLdapContext().createSubcontext(userDN, container);
						String body = "A user has been created for "
								+ parameters.getEnvironmentsOfClientType(client, environmentTag) + " Credentials are:"
								+ "\n" + "UserName : " + parameters.getField("id") + "\n" + "Password : " + userPassword
								+ "\n";
						addToResponseMap.put("client", client);
						addToResponseMap.put("body", body);
						centralService.addToResponseMail(requestID, addToResponseMap.get("client"),
								addToResponseMap.get("body"), environmentTag);
						clientEnv.getLdapContext().close();
						results.addInfoMessage(client, environmentTag, landscape, "Response : user created ");
						return results;
					}
				} catch (InvalidNameException e1) {

					results.addInfoMessage(client, environmentTag, landscape,
							"Invalid LDAP Name : User creation Error");
					return results;
				}

				catch (NamingException e) {

					results.addInfoMessage(client, environmentTag, landscape,
							"User creation error .Check if user already exidts");
					return results;
				} catch (ParseException e) {

					results.addInfoMessage(client, environmentTag, landscape, "User creation error " + e.toString());
					return results;
				}

			}
		}

		return results;
	}

	@Override
	public ResultsBlock userUpdate(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "User updated");
		return result;
	}

	@SuppressWarnings({ "unused" })
	@Override
	public ResultsBlock resetPassword(Parameters parameters) {
		Map<String, String> hashMap = new HashMap<>();
		StringBuffer sb = new StringBuffer();
		ResultsBlock results = new ResultsBlock();
		String password = passwordGenerator();
		String requestID = parameters.getField("RequestID");

		for (String client : parameters.getClients()) {
			ClientContext clientContext = clients.get(client);
			if (clientContext == null) {

				results.addInfoMessage(client, environmentTag, "client Context " + clientContext + "does not exist",
						requestID);
				return results;
			}
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {

				ClientEnvironmentConfiguration clientEnv = clientContext.getEnvironmentConfiguration(landscape);

				if (clientEnv == null) {

					results.addInfoMessage(client, environmentTag, "client environment " + clientEnv + "does not exist",
							requestID);
					return results;
				}
				clientEnv.getLdapContext();
				ArrayList<String> searchBases = clientEnv.getSearchBases();

				System.out.println(searchBases + " is the search base");

				LdapName subjectDN = null;

				String search;

				try {
					for (int k = 0; k < searchBases.size(); k++) {
						{
							search = searchBases.get(k);
							System.out.println(search + " is the individual eleemnt of search base");

						}
						System.out.println(search + " is the search");
						subjectDN = new LdapName(search);
						List<Rdn> rdns = subjectDN.getRdns();
						for (int i = rdns.size() - 1; i >= 0; i--) {
							final Rdn rds = rdns.get(i);
							final Attributes attributes = rds.toAttributes();
							final Attribute cn = attributes.get("dc");

							if (cn != null) {

								final String value = (String) cn.get();
								if (value != null) {

									String[] a = value.split(",");

									for (int j = 0; j < a.length; j++) {
										String segments[] = a[j].split("=");
										String last = segments[segments.length - 1];

										sb.append(last).append(".");

									}
								}
							}
						}

						String domainName = sb.toString();
						int UF_ACCOUNTDISABLE = 0x0002;
						int UF_PASSWD_NOTREQD = 0x0020;
						// int UF_PASSWD_CANT_CHANGE = 0x0040;
						int UF_NORMAL_ACCOUNT = 0x0200;
						// int UF_DONT_EXPIRE_PASSWD = 0x10000;
						int UF_PASSWORD_EXPIRED = 0x800000;

						// Note that you need to create the user object before you can
						// set the password. Therefore as the user is created with no
						// password, user AccountControl must be set to the following
						// otherwise the Win2K3 password filter will return error 53
						// unwilling to perform.
						Attributes attrs = new BasicAttributes(true);
						attrs.put("userAccountControl", Integer.toString(
								UF_NORMAL_ACCOUNT + UF_PASSWD_NOTREQD + UF_PASSWORD_EXPIRED + UF_ACCOUNTDISABLE));

						ModificationItem[] mods = new ModificationItem[2];

						// Replace the "unicdodePwd" attribute with a new value
						// Password must be both Unicode and a quoted string
						String passwd = passwordGenerator();
						System.out.println("password before unicode conversion " + passwd);
						String newQuotedPassword = "\"" + passwd + "\"";
						byte[] newUnicodePassword = newQuotedPassword.getBytes("UTF-16LE");

						mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
								new BasicAttribute("unicodePwd", newUnicodePassword));
						mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(
								"userAccountControl", Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWORD_EXPIRED)));
						clientEnv.getLdapContext().modifyAttributes("CN=" + parameters.getField("id") + "," + search,
								mods);
						String body = "Password has been reset "
								+ parameters.getEnvironmentsOfClientType(client, environmentTag) + " Credentials are:"
								+ "\n" + "UserName : " + parameters.getField("id") + "\n" + "Password : " + password
								+ "\n";
						addToResponseMap.put("client", client);
						addToResponseMap.put("body", body);
						results.addInfoMessage(client, environmentTag, landscape, "User password Reset");

						centralService.addToResponseMail(requestID, addToResponseMap.get("client"),
								addToResponseMap.get("body"), environmentTag);
					}
				} catch (InvalidNameException e1) {

					results.addErrorMessage(client, environmentTag, landscape,
							"Password reset Error:Invalid LDAP name");
				}

				catch (NamingException e) {
					results.addInfoMessage(client, environmentTag, landscape, "Password reset Error:Naming not right");

				} catch (UnsupportedEncodingException e) {
					results.addErrorMessage(client, environmentTag, landscape,
							"Password reset Error:UnsupportedEncodingException");
				}

			}
		}
		return results;
	}

	/*
	 * return the environment Name
	 */
	@Override
	public String getUser() {
		return this.environmentTag;
	}

	/**
	 * Millis to filetime.
	 *
	 * @param millis
	 *            the millis
	 * @return the long
	 */
	private static long millisToFiletime(long millis) {
		return (millis + FILETIME_EPOCH_DIFF) * FILETIME_ONE_MILLISECOND;
	}

	/**
	 * Password generator.
	 *
	 * @return the string
	 */
	static String passwordGenerator() {
		int MAX_LENGTH = 12;
		String DIGITS = "23456789";
		String LOCASE_CHARACTERS = "abcdefghjkmnpqrstuvwxyz";
		String UPCASE_CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZ";

		String ALL = DIGITS + LOCASE_CHARACTERS + UPCASE_CHARACTERS;// + SYMBOLS;
		char[] upcaseArray = UPCASE_CHARACTERS.toCharArray();
		char[] locaseArray = LOCASE_CHARACTERS.toCharArray();
		char[] digitsArray = DIGITS.toCharArray();
		// char[] symbolsArray = SYMBOLS.toCharArray();
		char[] allArray = ALL.toCharArray();
		Random r = new Random();

		StringBuilder sb = new StringBuilder();

		// get at least one lowercase letter
		sb.append(locaseArray[r.nextInt(locaseArray.length)]);

		// get at least one uppercase letter
		sb.append(upcaseArray[r.nextInt(upcaseArray.length)]);

		// get at least one digit
		sb.append(digitsArray[r.nextInt(digitsArray.length)]);

		// get at least one symbol
		// sb.append(symbolsArray[r.nextInt(symbolsArray.length)]);

		// fill in remaining with random letters
		for (int i = 0; i < MAX_LENGTH - 4; i++) {
			sb.append(allArray[r.nextInt(allArray.length)]);
		}

		return sb.toString();
	}

	/*
	 * validates date
	 */
	@Override
	public ResultsBlock validateParameters(Parameters params) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		ResultsBlock result = new ResultsBlock();
		String dateInString = params.getField("end_date");

		try {
			Date date = sdf.parse(dateInString);
			date.toString();

			return result;

		} catch (ParseException e) {
			result.addErrorMessage("", "", "", "DateFormat needs to be passed in dd-mm-yyyy hh:mm:ss");
			e.printStackTrace();
		}

		return result;
	}



	/*
	 * Initializes a central user
	 */
	@Override
	public void initialize(CentralServices centralServices) {
		this.setCentralServices(centralServices);
		this.loadConfiguration();
		this.centralService.registerUserManagementPlugin("ActiveDirectoryPlugin", environmentTag, version, this);
	}

	/*
	 * 
	 * Assigns a role to User
	 * 
	 */
	@Override
	public ResultsBlock userRoleAssign(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "User Role Updated");
		return result;
	}

	/*
	 * Deletes a User
	 */
	@Override
	public ResultsBlock userDelete(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "User deleted");
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#lockUser(com.capgemini.dac.
	 * automate.Parameters)
	 */
	@Override
	public ResultsBlock lockUser(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "User unlocked");
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#extendValidity(com.capgemini.
	 * dac.automate.Parameters)
	 */
	@Override
	public ResultsBlock extendValidity(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "NA");
		return result;
	}

}