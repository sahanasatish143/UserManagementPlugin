/*
 *  Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.logging.Logger;
import com.capgemini.dac.automate.CentralServices;
import com.capgemini.dac.automate.UserManagementPlugin;

/**
 * Manages plugin classes. The main method (loadPlugins) loads jars from a
 * specific directory. It parses each jar for the class that implements the
 * plugin. When it finds it, it automatically registers it in the plugin map.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * 
 */
public class PluginManager {
	
	/** The plugin map. */
	private static Map<String, UserManagementPlugin> pluginMap;
	
	/** The logger. */
	private Logger logger;
	
	/** The centralservices. */
	private CentralServices centralservices;
	
	/** The my singleton instance. */
	private static PluginManager mySingleton_instance = null;

	/**
	 * Instantiates a new plugin manager.
	 *
	 * @param centralServices the central services
	 */
	private PluginManager(CentralServices centralServices) {
		pluginMap = new HashMap<String, UserManagementPlugin>();
		setCentralServices(centralServices);
		logger = centralservices.getLogger();
		centralservices.registerPluginManager(this);
		loadPlugins();
	}

	/**
	 * Gets the single instance of PluginManager.
	 *
	 * @param centralServices the central services
	 * @return single instance of PluginManager
	 */
	public static PluginManager getInstance(CentralServices centralServices) {
		if (mySingleton_instance == null) {
			mySingleton_instance = new PluginManager(centralServices);
		}
		return mySingleton_instance;
	}

	/**
	 * Sets the central services.
	 *
	 * @param centralServices the new central services
	 */
	private void setCentralServices(CentralServices centralServices) {
		this.centralservices = centralServices;
	}

	/**
	 * For each jar file in the given plugin directory, it parses the jar in search
	 * of a class that implements UserManagementPlugin, it instantiates it and
	 * registers it in pluginMap.
	 */
	public void loadPlugins() {
		File pluginsDir = new File(this.centralservices.getPathToPlugins());
		System.out.println(pluginsDir);
		// for each jar file in plugin directory
		for (File jarFile : pluginsDir.listFiles()) {
			JarInputStream jarInputStream = null;
			try {
				jarInputStream = new JarInputStream(new FileInputStream(jarFile));
				// parse the jar in search of class that implements UserManagementPlugin
				JarEntry jarEntry = jarInputStream.getNextJarEntry();
				while (jarEntry != null) {
					if (jarEntry.getName().endsWith(".class")) {
						String rawEntryName = jarEntry.getName();
						logger.info("Checking " + rawEntryName);
						String classFileName = rawEntryName.replaceAll("/", "\\.");
						String className = classFileName.substring(0, classFileName.lastIndexOf('.'));
						logger.info("Checking " + className);
						ClassLoader loader = URLClassLoader.newInstance(new URL[] { jarFile.toURI().toURL() },
								PluginManager.class.getClassLoader());
						Class<?> loadedClass = Class.forName(className, true, loader);
						logger.info("loadedClass:" + loadedClass);

						// TODO: I tried to generalize the call to isAssignableFrom below
						// using template classes with no luck. If we can find a way to
						// generalize it, this plugin manager class can then be reused for
						// any plugin class
						// if class implements UserManagementPlugin
						if (UserManagementPlugin.class.isAssignableFrom(loadedClass)
								& UserManagementPlugin.class != loadedClass)

						{
							logger.info(loadedClass + " implements  plugin");

							Constructor<?> constructor = loadedClass.getConstructor();

							UserManagementPlugin pluginInstance = (UserManagementPlugin) constructor.newInstance();

							pluginInstance.initialize(this.centralservices);
							String environment = (String) pluginInstance.getUser();
							logger.info("get map method coming");
							logger.info("Plugin Name: " + environment);
							// register in our plugin map

						} else {
							logger.info(loadedClass + " DOES NOT implement Plugin plugin");
						}
					}
					jarEntry = jarInputStream.getNextJarEntry();
				} 
			} catch (Exception e) {
				// there might be multiple JARs in the directory, so keep looking
				e.printStackTrace();
				logger.severe(e.getMessage());
				continue;
			} finally {
				try {
					jarInputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
					logger.severe(e.getMessage());
					logger.info(e + " log mess");
				}
			}
		}
	}

	/**
	 * Register plugin.
	 * For Each request we will be using the plugin instance created
	 *
	 * @param environ the environ
	 * @param pluginInstance the plugin instance
	 */
	public void registerPlugin(String environ, UserManagementPlugin pluginInstance) {
		pluginMap.put(environ, pluginInstance);
	}

	/**
	 * Returns the plugin that corresponds to the given Plugin engine name.
	 *
	 * @param environment the environment
	 * @return Plugin that corresponds to given name
	 */
	public UserManagementPlugin getPlugin(String environment) {
		return pluginMap.get(environment);
	}

}
