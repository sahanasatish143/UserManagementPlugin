package com.capgemini.dac.automate;

import java.util.Random;


/**
 * The Class PasswordGenerator.
 * Generates a random password
 */
public class PasswordGenerator {
	
	/** The Constant DIGITS. */
	private static final char[] DIGITS = "23456789".toCharArray();
	
	/** The Constant LOCASE_CHARACTERS. */
	private static final char[] LOCASE_CHARACTERS = "abcdefghjkmnopqrstuvwxyz".toCharArray();
	
	/** The Constant UPCASE_CHARACTERS. */
	private static final char[] UPCASE_CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZ".toCharArray();
	
	/** The minimum length. */
	private int minimumLength;
	
	/** The maximum length. */
	private int maximumLength;
	
	/** The upper. */
	private boolean upper;
	
	/** The lower. */
	private boolean lower;
	
	/** The number. */
	private boolean number;
	
	/** The symbol. */
	private boolean symbol;
	
	/** The symbols. */
	private char[] symbols;
	
	/** The all. */
	private char[] all;

	/**
	 * Instantiates a new password generator.
	 */
	public PasswordGenerator() {
		minimumLength = 8;
		maximumLength = 24;
		upper = true;
		lower = true;
		number = true;
		symbol = true;
		symbols = "@#$%=:?".toCharArray();
		StringBuilder sb = new StringBuilder();
		sb.append(UPCASE_CHARACTERS);
		sb.append(LOCASE_CHARACTERS);
		sb.append(DIGITS);
		sb.append(symbols);
		all = sb.toString().toCharArray();
	}

	/**
	 * Instantiates a new password generator.
	 *
	 * @param minLength the min length
	 * @param maxLength the max length
	 * @param ucase the ucase
	 * @param lcase the lcase
	 * @param num the num
	 * @param sym the sym
	 * @param syms the syms
	 */
	public PasswordGenerator(int minLength, // max lenth-12
			int maxLength, boolean ucase, boolean lcase, boolean num, boolean sym, String syms) {
		if(!ucase & !lcase & !num & !sym)
			throw new RuntimeException("Error: at least one character class must be included!");
		if (maxLength < minLength)
			throw new RuntimeException("Error: maximum length must be greater than or equal to minimum length!");
		if (sym && (syms == null || syms.length() == 0))
			throw new RuntimeException(
					"Error: symbols where requested in this generator but no symbols where provided!");
		minimumLength = minLength;
		maximumLength = maxLength;
		upper = ucase;
		lower = lcase;
		number = num;
		symbol = sym;
		StringBuilder sb = new StringBuilder();
		if (ucase)
			sb.append(UPCASE_CHARACTERS);
		if (lcase)
			sb.append(LOCASE_CHARACTERS);
		if (num)
			sb.append(DIGITS);
		if (sym) {
			symbols = syms.toCharArray();
			sb.append(symbols);
		}
		all = sb.toString().toCharArray();
	}

	/**
	 * Generate.
	 *
	 * @return the string
	 */
	public String generate() {
		return generate(maximumLength);
	}

	/**
	 * Generate.
	 * with the dynamic length
	 *
	 * @param length the length
	 * @return the string
	 */
	public String generate(int length) {
		int plength;
		if (length < minimumLength)
			plength = minimumLength;
		else
			plength = length;
		Random r = new Random();
		StringBuilder sb = new StringBuilder();
		if (upper)
			sb.append(UPCASE_CHARACTERS[r.nextInt(UPCASE_CHARACTERS.length)]);
		if (lower)
			sb.append(LOCASE_CHARACTERS[r.nextInt(LOCASE_CHARACTERS.length)]);
		if (number)
			sb.append(DIGITS[r.nextInt(DIGITS.length)]);
		if (symbol)
			sb.append(symbols[r.nextInt(symbols.length)]);
		for (int i = 0; i < plength - 4; i++) {
			sb.append(all[r.nextInt(all.length)]);
		}
		return sb.toString();
	}
}