package com.capgemini.dac.automate;

/**
 * The Class MessagePart.
 */
public class MessagePart {

	/** The request id. */
	String requestId;
	
	/** The client. */
	String  client;
	
	/** The environment. */
	String environment;
	
	/** The body. */
	String body;
	
	/**
	 * Instantiates a new message part.
	 *
	 * @param requestId the request id
	 * @param client the client
	 * @param environment the environment
	 * @param body the body
	 */
	public MessagePart(String requestId, String client, String environment, String body) {
		
		this.requestId = requestId;
		this.client = client;
		this.environment = environment;
		this.body = body;
	}
	
	/**
	 * Gets the client.
	 *
	 * @return the client
	 */
	public String getClient() {
		return client;
	}
	
	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}
	
	/**
	 * Gets the body.
	 *
	 * @return the body
	 */
	public String getBody() {
		return body;
	}
	
	
	
}
