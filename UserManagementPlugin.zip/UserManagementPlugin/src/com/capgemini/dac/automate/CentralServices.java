/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate;

import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.*;
import java.util.logging.Logger;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * Represents a collection of Tasks for email.
 * 
 * @author sahana.b.s@capgemini.com
 * @version 1.0
 * @since 1.8
 */
public class CentralServices {

	private Logger logger;
	private HashMap<String, Request> requestMap = new HashMap<String, Request>();
	private HashMap<String, String> configurationFiles;
	private HashMap<String, String> emailConfiguration;

	PluginManager pluginManager;

	private String pathToPlugins;
	private String pathToLibrary;

	/**
	 * Constructor to build a default CentralServices object.
	 */
	public CentralServices() {
		String componentName = null;
		getConfigFilename(componentName);
	}

	public CentralServices(String mainConfigFile) {
		configurationFiles = new HashMap<String, String>();
		configurationFiles.put("UserManagementService", mainConfigFile);
		loadMainConfiguration();
	}

	public void registerPluginManager(PluginManager pluginManager) {
		this.pluginManager = pluginManager;
	}

	private void loadMainConfiguration() {
		String configurationFile = this.getConfigFilename("UserManagementService");
		JSONParser jsonParser = new JSONParser();
		try {
			JSONObject jasonobj = (JSONObject) jsonParser.parse(new FileReader(configurationFile));
			this.pathToPlugins = (String) jasonobj.get("plugin_path");
			this.pathToLibrary = (String) jasonobj.get("library_path");
			parseEmailConfiguration((JSONObject) jasonobj.get("email"));
			parsePluginFileLocations((JSONObject) jasonobj.get("plugins"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		addLibraryJars();
	}

	private void addLibraryJars() {
		File pluginsDir = new File(this.pathToLibrary);

		URLClassLoader systemClassLoader = (URLClassLoader) ClassLoader.getSystemClassLoader();
		Class<URLClassLoader> classLoaderClass = URLClassLoader.class;
		Method method = null;
		try {
			method = classLoaderClass.getDeclaredMethod("addURL", new Class[] { URL.class });
			method.setAccessible(true);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}

		for (File jarFile : pluginsDir.listFiles()) {
			if (jarFile.getName().endsWith(".jar")) {
				try {
					URL url = jarFile.toURI().toURL();
					method.invoke(systemClassLoader, new Object[] { url });
				} catch (Throwable t) {
					t.printStackTrace();
				}
			}
		}

	}

	private void parsePluginFileLocations(JSONObject jsonObject) {
		for (Iterator<?> iterator = jsonObject.keySet().iterator(); iterator.hasNext();) {
			String key = (String) iterator.next();
			JSONObject pluginConfig = (JSONObject) jsonObject.get(key);
			String fileName = (String) pluginConfig.get("config_file");
			if (fileName == null)
				configurationFiles.put(key, this.getConfigFilename("UserManagementService"));
			else
				configurationFiles.put(key, fileName);
		}
	}

	private HashMap<String, String> parseEmailConfiguration(JSONObject emailconfig) {
		emailConfiguration = new HashMap<String, String>();
		emailConfiguration.put("User", (String) emailconfig.get("user"));
		emailConfiguration.put("Password", (String) emailconfig.get("password"));
		emailConfiguration.put("SMTP_Auth", (String) emailconfig.get("smtp_auth"));
		emailConfiguration.put("StartTTLS_Enable", (String) emailconfig.get("starttls_enable"));
		emailConfiguration.put("Host", (String) emailconfig.get("host"));
		emailConfiguration.put("Port", (String) emailconfig.get("port"));
		return emailConfiguration;
	}

	/**
	 * This method allows a component to retrieve the location of its configuration
	 * file from the host application. This depends on the plugin's configuration
	 * being specified in the main configuration file.
	 *
	 * @param componentName
	 *            the name of the component requesting its configuration file
	 * @returns fully qualified name of a component configuration file
	 */
	public String getConfigFilename(String componentName) {
		return this.configurationFiles.get(componentName);
	}

	/**
	 * Provides access to the applications central logger.
	 *
	 * @returns the central logger instance
	 */
	public Logger getLogger() {
		return logger;
	}

	/**
	 * This method allows UserManagementPlugin to register its active instance with
	 * the central environment for usage.
	 *
	 * @param pluginName
	 *            the name class name of the plugin
	 * @param pluginIdentifyer
	 *            the JSON tag used to denote the plugin environment
	 * @param version
	 *            the version of the plugin
	 * @param pluginObject
	 *            a reference to the loaded instance of the plugin
	 */
	public void registerUserManagementPlugin(String pluginName, String pluginIdentifyer, String version,
			UserManagementPlugin pluginObject) {
		pluginManager.registerPlugin(pluginIdentifyer, pluginObject);
	}

	/**
	 * This method initialize a single mail as a response to a request that can be
	 * coordinated by multiple components.
	 *
	 * @param requestID
	 *            the id of the request that is being replied to
	 * @param eMail
	 *            the recipient email address
	 * @param subject
	 *            the subject of the mail
	 * @param salutation
	 *            the salutation of the mail
	 * @param Signature
	 *            the signature of the mail
	 */

	public void registerLogger(Logger logger) {
		this.logger = logger;
	}

	public void addToResponseMail(String requestID, String client, String body, String environment) {

		Request request = requestMap.get(requestID);
		request.addMessagePart(client, environment, body);
		requestMap.put(requestID, request);

	}

	public void initializeResponseMail(String requestID, String eMail, String subject, String salutation,
			String Signature) {

		requestMap.put(requestID, new Request(requestID, eMail, subject, salutation, Signature));

	}

	public void finalizeAndSendResponseMail(String requestID) {
		Request request = requestMap.get(requestID);
		StringBuilder body = new StringBuilder();
		body.append(request.getSalutation());
		body.append("\n\n");
		for (String client : request.getClientList()) {
			body.append("For the customer ").append(client).append(":\n");
			for (String environment : request.getEnvironmentByClient(client)) {

				body.append("For the environment ").append(environment).append(":\n");

				for (String chunk : request.getBodyChunkByclientEnvironment(client, environment)) {

					body.append(chunk);

					body.append("\n\n");

				}

			}
		}
		body.append(request.getSignature());

		final String from = emailConfiguration.get("User");
		final String password = emailConfiguration.get("Password");

		Properties props = new Properties();
		props.put("mail.smtp.auth", emailConfiguration.get("SMTP_Auth"));
		props.put("mail.smtp.starttls.enable", emailConfiguration.get("StartTTLS_Enable"));
		props.put("mail.smtp.host", emailConfiguration.get("Host"));
		props.put("mail.smtp.port", emailConfiguration.get("Port"));

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});
		try {

			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(request.getEmail()));

			message.setSubject(request.getSubject());

			message.setText(body.toString());

			Transport.send(message);

		}

		catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @return the pathToPlugins
	 */
	public String getPathToPlugins() {
		return this.pathToPlugins;
	}

	public String registerRequest(String action, Parameters parameters) {
		String id = UUID.randomUUID().toString();
		requestMap.put(id, new Request(id, action));
		return id;
	}
}