package com.capgemini.dac.automate;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Sahana S;@sahana.b.s@capgemini.com
 *
 */
public class EnvironmentParameters
{
  
  /** The environment. */
  String environment;
  
  /** The client. */
  String client;
  
  /** The landscape. */
  String landscape;
  
  /** The permissions. */
  ArrayList<String> permissions;
  
  /**
   * Instantiates a new environment parameters.
   */
  public EnvironmentParameters() {
    permissions = new ArrayList<String>();
  }
  
  /**
   * Instantiates a new environment parameters.
   *
   * @param client the client
   * @param environment the environment
   * @param landscape the landscape
   */
  public EnvironmentParameters ( String client,String environment,String landscape) {
    permissions = new ArrayList<String>();
    this.setClient(client);
    this.setEnvironment(environment);
    this.setLandscape(landscape);
  }
  
  /**
   * Gets the client.
   *
   * @return the client
   */
  public String getClient() {
    return client;
  }
  
  /**
   * Sets the client.
   *
   * @param client the new client
   */
  public void setClient(String client) {
    this.client = client;
  }
  
  /**
   * Gets the environment.
   *
   * @return the environment
   */
  public String getEnvironment() {
    return environment;
  }

  /**
   * Sets the environment.
   *
   * @param environment the new environment
   */
  public void setEnvironment(String environment) {
    this.environment = environment;
  }
  
  /**
   * Gets the landscape.
   *
   * @return the landscape
   */
  public String getLandscape() {
    return landscape;
  }

  /**
   * Sets the landscape.
   *
   * @param landscape the new landscape
   */
  public void setLandscape(String landscape) {
    this.landscape = landscape;
  }
  
  /**
   * Iterator.
   *
   * @return the iterator
   */
  public Iterator<String> iterator() {
    return permissions.iterator();
  }
  
  /**
   * Adds the.
   *
   * @param permission the permission
   */
  public void add(String permission) {
    permissions.add(permission);
  }
}