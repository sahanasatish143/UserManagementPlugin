package com.capgemini.dac.automate;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Sahana S;sahana.b.s@capgemini.com The Class Request.
 * Contains the message part for an email
 */

public class Request {

	/** The id. */
	String ID;

	/** The ms part. */
	List<MessagePart> msPart;

	/** The email. */
	String email;

	/** The subject. */
	String subject;

	/** The salutation. */
	String salutation;

	/** The Signature. */
	String Signature;

	/**
	 * Instantiates a new request.
	 *
	 * @param iD
	 *            the i D
	 */
	public Request(String iD,String action) {

		ID = iD;
		msPart = new ArrayList<MessagePart>();
	}

	/**
	 * Instantiates a new request.
	 *
	 * @param iD
	 *            the i D
	 * @param email
	 *            the email
	 * @param subject
	 *            the subject
	 * @param salutation
	 *            the salutation
	 * @param signature
	 *            the signature
	 */
	public Request(String iD, String email, String subject, String salutation, String signature) {

		ID = iD;
		this.email = email;
		this.subject = subject;
		this.salutation = salutation;
		Signature = signature;
		msPart = new ArrayList<MessagePart>();
	}

	/**
	 * Gets the body chunk byclient environment.
	 *
	 * @param client
	 *            the client
	 * @param environment
	 *            the environment
	 * @return the body chunk byclient environment
	 */
	public List<String> getBodyChunkByclientEnvironment(String client, String environment) {
		ArrayList<String> result = new ArrayList<String>();
	    for (MessagePart temp : msPart)
	    {
	      if (!result.contains(temp.getBody()))
	        result.add(temp.getBody());
	    }
	    return result;
	}

	/**
	 * Adds the message part.
	 *
	 * @param client
	 *            the client
	 * @param environment
	 *            the environment
	 * @param body
	 *            the body
	 */
	public void addMessagePart(String client, String environment, String body) {

		msPart.add(new MessagePart(ID, client, environment, body));

	}

	/**
	 * Adds the message part.
	 *
	 * @param msgPrt
	 *            the msg prt
	 */
	public void addMessagePart(MessagePart msgPrt) {
		msPart.add(msgPrt);
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Gets the subject.
	 *
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * Gets the salutation.
	 *
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}

	/**
	 * Gets the signature.
	 *
	 * @return the signature
	 */
	public String getSignature() {
		return Signature;
	}

	/**
	 * Gets the client list.
	 *
	 * @return the client list
	 */
	public List<String> getClientList() {
		ArrayList<String> result = new ArrayList<String>();
		for (MessagePart temp : msPart) {
			if (!result.contains(temp.getClient()))
				result.add(temp.getClient());
		}
		return result;// set to read client...
	}

	/**
	 * Gets the environment by client.
	 *
	 * @param client
	 *            the client
	 * @return the environment by client
	 */
	public List<String> getEnvironmentByClient(String client) {
		ArrayList<String> result = new ArrayList<String>();
		for (MessagePart temp : msPart) {
			if (!result.contains(temp.getEnvironment()))
				result.add(temp.getEnvironment());
		}
		return result;
	}

}
