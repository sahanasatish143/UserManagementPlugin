/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate;

import java.util.HashMap;

/**
 * The Interface SAPPluginInterface. * This class represents the contract for
 * SAP Plugin developers. All plugin implementation classes must implement this
 * interface.
 * 
 * IMPORTANT: When using this JAR inside a Maven project, make sure you run the
 * following Maven command:
 * 
 * mvn install:install-file -Dfile=<path to exported JAR>
 * -DgroupId=com.capgemini.dac.automate -DartifactId=UserProvisioningPlugin
 * -Dversion=1.0 -Dpackaging=jar -DgeneratePom=true
 * 
 * This will install the library in your local Maven repo. Then include the
 * following dependency in your pom file:
 * 
 * <dependency> <groupId>com.capgemini.dac.automate</groupId>
 * <artifactId>UserProvisioningPlugin</artifactId> <version>1.0</version>
 * </dependency>
 * 
 * Note version numbers could change. The above is just an example.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * 
 */
public interface UserManagementPlugin {

	/**
	 * This method shall return the name (or rather the key) of the functionality
	 * plugin you are implementing, e.g. "userCreate","changePassword",or"userInfo".
	 * This name will automatically get registered in the PluginManager such that
	 * when an API call is received (e.g. http://<API_URL>/user/provisioning) the
	 * web service knows how/who to direct the call to.
	 *
	 * @return Name/key of plugin being implemented, e.g. "userCreate"
	 */

	//Used to return the environment tag to user
	public String getUser();

	/** The request map. */
	static HashMap<String, Object> requestMap = new HashMap<String, Object>();

	/**
	 * Creates the user.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock createUser(Parameters parameters);

	/**
	 * Validate parameters.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock validateParameters(Parameters parameters);

	/**
	 * Initialize.
	 *
	 * @param centralServices the central services
	 */
	public void initialize(CentralServices centralServices);

	/**
	 * User role assign.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock userRoleAssign(Parameters parameters);

	/**
	 * Reset password.
	 *
	 * @param parameters the parameters
	 * @return the string
	 */
	public ResultsBlock resetPassword(Parameters parameters);

	/**
	 * User update.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock userUpdate(Parameters parameters);

	/**
	 * User delete.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock userDelete(Parameters parameters);

	/**
	 * Lock user.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock lockUser(Parameters parameters);

	/**
	 * Extend validity.
	 *
	 * @param parameters the parameters
	 * @return the results block
	 */
	public ResultsBlock extendValidity(Parameters parameters);

}
