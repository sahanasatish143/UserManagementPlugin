package com.capgemini.dac.automate;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The Class Parameters. Contains the request paramers json
 */
public class Parameters {

	/** The properties. */
	Properties properties = new Properties();

	/** The environments. */
	ArrayList<EnvironmentParameters> environments = new ArrayList<EnvironmentParameters>();

	/** The roles. */
	ArrayList<String> roles = new ArrayList<String>();

	/**
	 * Instantiates a new parameters.
	 */
	public Parameters() {
		this.addField("Version", "1.0.0");
	}

	/**
	 * Instantiates a new parameters.
	 *
	 * @param version
	 *            the version
	 */
	public Parameters(String version) {
		this.addField("Version", version);
	}

	/**
	 * Initialize from JSON.
	 *
	 * @param json
	 *            the json
	 * @return the parameters
	 */
	public Parameters initializeFromJSON(String json) {
		try {
			JSONObject jsonObject = new JSONObject(json);
			Iterator<String> it = jsonObject.keys();
			while (it.hasNext()) {
				String key = it.next();
				if (key.equalsIgnoreCase(("customers")))
					this.parseCustomers(jsonObject.get(key).toString());
				else if (key.equalsIgnoreCase("roles"))
					this.parseRoles(jsonObject.get(key).toString());
				else
					this.properties.put(key, jsonObject.get(key));
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return this;
	}

	/**
	 * Parses the customers.
	 *
	 * @param json
	 *            the json
	 */
	private void parseCustomers(String json) {
		try {
			JSONObject jsonObject = new JSONObject(json);
			Iterator<String> it = jsonObject.keys();
			while (it.hasNext()) {

				String key = it.next();
				String value = jsonObject.get(key).toString();
				paserEnvironment(key, value);

			}
		} catch (Exception ex) {
			System.out.println(ex);
		}

	}

	/**
	 * Parses the roles.
	 *
	 * @param json
	 *            the json
	 */
	private void parseRoles(String json) {
		try {
			JSONArray roles = new JSONArray(json);
			Iterator<Object> vit = roles.iterator();
			while (vit.hasNext()) {
				this.roles.add(vit.next().toString());
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	/**
	 * Paser environment.
	 *
	 * @param customer
	 *            the customer
	 * @param json
	 *            the json
	 */
	private void paserEnvironment(String customer, String json) {
		try {
			JSONObject jsonObject = new JSONObject(json);
			Iterator<String> it = jsonObject.keys();
			while (it.hasNext()) {
				String plugin = it.next();
				JSONObject jsonEnvironments = (JSONObject) jsonObject.get(plugin);
				Iterator<String> eit = jsonEnvironments.keys();
				while (eit.hasNext()) {
					String environment = eit.next();
					JSONObject value = (JSONObject) jsonEnvironments.get(environment);
					Iterator<String> lit = value.keys();
					while (lit.hasNext()) {
						String landscape = lit.next();
						EnvironmentParameters enviro = new EnvironmentParameters(customer, plugin, landscape);
						this.environments.add(enviro);
					}
				}
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	/**
	 * Checks for field.
	 *
	 * @param key
	 *            the key
	 * @return true, if successful
	 */
	public boolean hasField(String key) {
		if (key.equalsIgnoreCase("roles")) {

			return roles.size() != 0;
		}
		if (key.equalsIgnoreCase("customers")) {

			return environments.size() != 0;
		}
		return properties.containsKey(key);
	}

	public boolean ignoreCase(String key) {
		return key.equalsIgnoreCase(properties.getProperty(key));

	}

	/**
	 * Adds the field.
	 *
	 * @param name
	 *            the name
	 * @param value
	 *            the value
	 * @return the properties
	 */
	public Properties addField(String name, String value) {
		properties.setProperty(name, value);
		return properties;
	}

	/**
	 * Gets the clients.
	 *
	 * @return the clients
	 */
	public ArrayList<String> getClients() {
		ArrayList<String> result = new ArrayList<String>();
		for (EnvironmentParameters temp : environments) {
			if (!result.contains(temp.getClient()))
				result.add(temp.getClient());
		}
		return result;
	}

	/**
	 * Gets the environment names.
	 *
	 * @return the environment names
	 */
	public ArrayList<String> getEnvironmentNames() {
		ArrayList<String> result = new ArrayList<String>();
		for (EnvironmentParameters temp : environments) {
			if (!result.contains(temp.getEnvironment()))
				result.add(temp.getEnvironment());
		}
		return result;
	}

	/**
	 * Gets the landscapes.
	 *
	 * @return the landscapes
	 */
	public ArrayList<String> getLandscapes() {
		ArrayList<String> result = new ArrayList<String>();
		for (EnvironmentParameters temp : environments) {
			if (!result.contains(temp.getLandscape()))
				result.add(temp.getLandscape());
		}
		return result;
	}

	/**
	 * Gets the landscapes for environment.
	 *
	 * @param environment
	 *            the environment
	 * @return the landscapes for environment
	 */
	public ArrayList<String> getLandscapesForEnvironment(String environment) {
		ArrayList<String> result = new ArrayList<String>();
		for (EnvironmentParameters temp : environments) {
			if (temp.getEnvironment().equals(environment) && !result.contains(temp.getLandscape()))
				result.add(temp.getLandscape());
		}
		return result;
	}

	/**
	 * Gets the environments of type.
	 *
	 * @param type
	 *            the type
	 * @return the environments of type
	 */
	public ArrayList<EnvironmentParameters> getEnvironmentsOfType(String type) {
		ArrayList<EnvironmentParameters> result = new ArrayList<EnvironmentParameters>();
		for (EnvironmentParameters temp : environments) {
			if (temp.getEnvironment().equals(type))
				result.add(temp);
		}
		return result;
	}

	/**
	 * Gets the environments of client.
	 *
	 * @param client
	 *            the client
	 * @return the environments of client
	 */
	public ArrayList<EnvironmentParameters> getEnvironmentsOfClient(String client) {
		ArrayList<EnvironmentParameters> result = new ArrayList<EnvironmentParameters>();
		for (EnvironmentParameters temp : environments) {
			if (temp.getClient().equals(client))
				result.add(temp);
		}
		return result;
	}

	/**
	 * Field names.
	 *
	 * @return the enumeration
	 */
	@SuppressWarnings("unchecked")
	public Enumeration<String> fieldNames() {
		return (Enumeration<String>) properties.propertyNames();
	}

	/**
	 * Gets the field.
	 *
	 * @param name
	 *            the name
	 * @return the field
	 */
	public String getField(String name) {
		return properties.getProperty(name);
	}

	/**
	 * Gets the environments of client type.
	 *
	 * @param client
	 *            the client
	 * @param environment
	 *            the environment
	 * @return the environments of client type
	 */
	public ArrayList<String> getEnvironmentsOfClientType(String client, String environment) {
		ArrayList<String> result = new ArrayList<String>();
		for (EnvironmentParameters temp : environments) {
			if (temp.getEnvironment().equals(environment) && !result.contains(temp.getLandscape()))
				result.add(temp.getLandscape());
		}
		return result;
	}
}