package com.capgemini.dac.automate;

/**
 * The Class ResultEntry.
 * This comes from ResultsBlock
 */
public class ResultEntry
{
  
  /** The level. */
  private String level;
  
  /** The customer. */
  private String customer;
  
  /** The environment. */
  private String environment;
  
  /** The landscape. */
  private String landscape;
  
  /** The message. */
  private String message;
  
  /**
   * Instantiates a new result entry.
   *
   * @param level the level
   * @param customer the customer
   * @param environment the environment
   * @param landscape the landscape
   * @param message the message
   */
  public ResultEntry(String level,String customer, String environment, String landscape,  String message) 
  {
    this.level = level;
    this.customer = customer;
    this.environment = environment;
    this.landscape = landscape;
    this.message = message;
  }

  /**
   * Gets the level.
   *
   * @return the level
   */
  public String getLevel()
  {
    return this.level;
  }

  /**
   * Gets the customer.
   *
   * @return the customer
   */
  public String getCustomer()
  {
    return this.customer;
  }

  /**
   * Gets the environment.
   *
   * @return the environment
   */
  public String getEnvironment()
  {
    return this.environment;
  }

  /**
   * Gets the message.
   *
   * @return the message
   */
  public String getMessage()
  {
    return this.message;
  }

  /**
   * Gets the landscape.
   *
   * @return the landscape
   */
  public String getLandscape()
  {
    return landscape;
  }
  
  
  
 }
