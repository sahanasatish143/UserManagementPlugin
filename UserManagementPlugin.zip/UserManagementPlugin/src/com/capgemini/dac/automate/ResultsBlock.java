package com.capgemini.dac.automate;

import java.util.*;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The Class ResultsBlock. Gives three types of results:Erro,warning,info
 */
public class ResultsBlock {

	/** The errored. */
	private boolean errored;

	/** The warning. */
	private boolean warning;

	/** The entries. */
	private List<ResultEntry> entries;

	/**
	 * Instantiates a new results block.
	 */
	public ResultsBlock() {
		errored = false;
		warning = false;
		entries = new ArrayList<ResultEntry>();
	}

	/**
	 * Instantiates a new results block.
	 *
	 * @param errored
	 *            the errored
	 * @param warning
	 *            the warning
	 */
	public ResultsBlock(boolean errored, boolean warning) {
		errored = false;
		warning = false;
		entries = new ArrayList<ResultEntry>();
	}

	/**
	 * Checks for errors.
	 *
	 * @return true, if successful
	 */
	public boolean hasErrors() {
		return errored;
	}

	/**
	 * Checks for warnings.
	 *
	 * @return true, if successful
	 */
	public boolean hasWarnings() {
		return warning;
	}

	/**
	 * Worst error level.
	 *
	 * @return the string
	 */
	public String worstErrorLevel() {
		if (errored)
			return "Error";
		else if (warning)
			return "Warning";
		else
			return "Info";
	}

	/**
	 * Merge results.
	 *
	 * @param createUser
	 *            the create user
	 * @return the results block
	 */
	public ResultsBlock mergeResults(ResultsBlock createUser) {
		this.errored = this.errored || createUser.errored;
		this.warning = this.warning || createUser.warning;
		if (entries.isEmpty()) {
			createUser.addErrorMessage("Global", "Global", "Global", "Check the entries from both the plugins");
		}
		entries.addAll(createUser.entries);
		return this;
	}

	/**
	 * To JSON response.
	 *
	 * @return the string
	 */
	public String toJSONResponse() {
		JSONObject jsonObject = new JSONObject();
		Set<String> customers = getListOfCustomers();

		for (String cust : customers) {
			JSONObject jsonCustomer = new JSONObject();
			Set<String> environemnt = getListOfEnvironemtnsForCustomer(cust);

			for (String env : environemnt) {
				JSONObject jsonEnvironemnt = new JSONObject();
				Set<String> landscape = getListOflandscapes(cust, env);

				for (String lands : landscape) {
					JSONObject jsonLandscape = new JSONObject();
					Set<String> messageLevel = getListOfmessageLevel(lands, cust, env);

					for (String levels : messageLevel) {
						JSONArray messages = new JSONArray();
						List<String> listEntries = getMessages(lands, cust, env, levels);

						for (String str : listEntries) {
							messages.put(str);

						}

						jsonLandscape.put(levels, messages);
					}
					jsonEnvironemnt.put(lands, jsonLandscape);
				}
				jsonCustomer.put(env, jsonEnvironemnt);
			}
			jsonObject.put(cust, jsonCustomer);
		}

		return jsonObject.toString();
	}

	/**
	 * Gets the messages.
	 *
	 * @param lands
	 *            the lands
	 * @param cust
	 *            the cust
	 * @param env
	 *            the env
	 * @param levels
	 *            the levels
	 * @return the messages
	 */
	private ArrayList<String> getMessages(String lands, String cust, String env, String levels) {
		ArrayList<String> result = new ArrayList<String>();
		for (ResultEntry temp : entries) {
			if (temp.getEnvironment().equals(env) && temp.getCustomer().equals(cust)
					&& temp.getLandscape().equals(lands) && temp.getLevel().equals(levels))

				result.add(temp.getMessage());
		}
		return result;
	}

	/**
	 * Gets the list ofmessage level.
	 *
	 * @param lands
	 *            the lands
	 * @param cust
	 *            the cust
	 * @param env
	 *            the env
	 * @return the list ofmessage level
	 */
	private Set<String> getListOfmessageLevel(String lands, String cust, String env) {
		Map<String, String> result = new HashMap<String, String>();// set not a map

		for (ResultEntry temp : entries) {
			if (temp.getCustomer().equals(cust) && temp.getEnvironment().equals(env)
					&& temp.getLandscape().equals(lands))

				result.put(temp.getLevel(), temp.getLevel());
		}
		return result.keySet();
	}

	/**
	 * Gets the list oflandscapes.
	 *
	 * @param cust
	 *            the cust
	 * @param env
	 *            the env
	 * @return the list oflandscapes
	 */
	private Set<String> getListOflandscapes(String cust, String env) {
		Map<String, String> result = new HashMap<String, String>();

		for (ResultEntry temp : entries) {
			if (temp.getCustomer().equals(cust) && temp.getEnvironment().equals(env))

				result.put(temp.getLandscape(), temp.getLandscape());

		}
		return result.keySet();
	}

	/**
	 * Gets the list of environemtns for customer.
	 *
	 * @param cust
	 *            the cust
	 * @return the list of environemtns for customer
	 */
	private Set<String> getListOfEnvironemtnsForCustomer(String cust) {
		Map<String, String> result = new HashMap<String, String>();

		for (ResultEntry temp : entries) {
			if (temp.getCustomer().equals(cust))

				result.put(temp.getEnvironment(), temp.getEnvironment());
		}
		return result.keySet();
	}

	/**
	 * Gets the list of customers.
	 *
	 * @return the list of customers
	 */
	private Set<String> getListOfCustomers() {

		Map<String, String> result = new HashMap<String, String>();
		for (ResultEntry temp : entries) {
			result.put(temp.getCustomer(), temp.getCustomer());

		}
		return result.keySet();

	}

	/**
	 * Adds the message.
	 *
	 * @param level
	 *            the level
	 * @param customer
	 *            the customer
	 * @param environment
	 *            the environment
	 * @param landscape
	 *            the landscape
	 * @param message
	 *            the message
	 * @return the results block
	 */
	public ResultsBlock addMessage(String level, String customer, String environment, String landscape,
			String message) {
		if (level.equalsIgnoreCase("error"))
			setErrors(true);
		else if (level.equalsIgnoreCase("warning"))
			setWarning(true);

		entries.add(new ResultEntry(level, customer, environment, landscape, message));
		return this;
	}

	/**
	 * Adds the info message.
	 *
	 * @param customer
	 *            the customer
	 * @param environment
	 *            the environment
	 * @param landscape
	 *            the landscape
	 * @param message
	 *            the message
	 * @return the results block
	 */
	public ResultsBlock addInfoMessage(String customer, String environment, String landscape, String message) {
		return addMessage("Info", customer, environment, landscape, message);
	}

	/**
	 * Adds the warning message.
	 *
	 * @param customer
	 *            the customer
	 * @param environment
	 *            the environment
	 * @param landscape
	 *            the landscape
	 * @param message
	 *            the message
	 * @return the results block
	 */
	public ResultsBlock addWarningMessage(String customer, String environment, String landscape, String message) {
		return addMessage("Warning", customer, environment, landscape, message);
	}

	/**
	 * Adds the error message.
	 *
	 * @param customer
	 *            the customer
	 * @param environment
	 *            the environment
	 * @param landscape
	 *            the landscape
	 * @param message
	 *            the message
	 * @return the results block
	 */
	public ResultsBlock addErrorMessage(String customer, String environment, String landscape, String message) {
		return addMessage("Error", customer, environment, landscape, message);
	}

	/**
	 * Sets the errors.
	 *
	 * @param b
	 *            the new errors
	 */
	public void setErrors(boolean b) {

	}

	/**
	 * Sets the warning.
	 *
	 * @param b
	 *            the new warning
	 */
	public void setWarning(boolean b) {

	}

}
