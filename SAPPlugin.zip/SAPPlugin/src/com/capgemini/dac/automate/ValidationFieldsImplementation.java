package com.capgemini.dac.automate;

import java.util.ArrayList;
import com.capgemini.dac.automate.Parameters;

/**
 * The Class ValidationFieldsImplementation.
 */
public class ValidationFieldsImplementation {
	
	/** The message. */
	String message;

	/**
	 * Gets the friendly format.
	 *
	 * @param parameters the parameters
	 * @return the friendly format
	 */
	public String getFriendlyFormat(Parameters parameters) {

		return message;

	}

	/**
	 * Checks if is field value valid.
	 *
	 * @param key the key
	 * @param field the field
	 * @return true, if is field value valid
	 */
	public boolean isFieldValueValid(String key, String field) {
		try {
			return true;
		} catch (Exception nfe) {
			return false;
		}
	}

	/**
	 * Checks if is field defined.
	 *
	 * @param key the key
	 * @return true, if is field defined
	 */
	public boolean isFieldDefined(String key) {

		return false;
	}

	/**
	 * Gets the required fields.
	 *
	 * @return the required fields
	 */
	public ArrayList<String> getRequiredFields() {
		ArrayList<String> arrlist = new ArrayList<String>();
		arrlist.add("id");
		arrlist.add("start_date");
		arrlist.add("end_date");
		arrlist.add("customers");
		arrlist.add("landscapes");
		return arrlist;
	}

	
	/**
	 * Gets the defualt fields.
	 *
	 * @return the defualt fields
	 */
	public ArrayList<String> getDefualtFields() {
		ArrayList<String> arrlist = new ArrayList<String>();
		arrlist.add("roles");
		arrlist.add("start_date");
		arrlist.add("end_date");
		arrlist.add("environments");
		return arrlist;
	}

	/**
	 * Gets the default value.
	 *
	 * @param name the name
	 * @return the default value
	 */
	public String getDefaultValue(String name) {

		return name;
	}
}