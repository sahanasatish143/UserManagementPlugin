/*
 *  Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;

public class DataProvider implements DestinationDataProvider {
	private static DataProvider singleton;
	private Map<String, Map<String, Map<String, String>>> customerSystemKeys;
	private Map<String, Properties> propertiesForDestinationName;
	private DestinationDataEventListener eventListener;

	/**
	 * Default constructor. Instantiates a new my sap dest data provider.
	 */
	private DataProvider() {
		customerSystemKeys = new HashMap<String, Map<String, Map<String, String>>>();
		propertiesForDestinationName = new HashMap<String, Properties>();
		com.sap.conn.jco.ext.Environment.registerDestinationDataProvider(this);
	}

	public static DataProvider getInstance() {
		if (singleton == null)
			singleton = new DataProvider();
		return singleton;
	}

	/**
	 * Adds the destination.
	 *
	 * @param destinationName
	 *            the destination name
	 * @param properties
	 *            the properties
	 */
	public void addDestination(String destinationName, Properties properties) {
		propertiesForDestinationName.put(destinationName, properties);
		eventListener.updated(destinationName);
	}

	public void addDestination(String customer, String sid, String ashost, String sysnr, String client, String user,
			String password, String lang) {
		String destinationName = customer.trim() + sid.trim() + client.trim();
		Map<String, Map<String, String>> systems = customerSystemKeys.getOrDefault(customer,
				new HashMap<String, Map<String, String>>());
		customerSystemKeys.put(customer, systems);
		Map<String, String> clients = systems.getOrDefault(sid, new HashMap<String, String>());
		systems.put(sid, clients);
		clients.put(client, destinationName);
		Properties props = new Properties();
		props.setProperty(DestinationDataProvider.JCO_ASHOST, ashost);
		props.setProperty(DestinationDataProvider.JCO_SYSNR, sysnr);
		props.setProperty(DestinationDataProvider.JCO_CLIENT, client);
		props.setProperty(DestinationDataProvider.JCO_USER, user);
		props.setProperty(DestinationDataProvider.JCO_PASSWD, password);
		props.setProperty(DestinationDataProvider.JCO_LANG, lang);
		addDestination(destinationName, props);
	}

	public void addDestination(String customer, String sid, String ashost, String sysnr, String client, String user,
			String password, String lang, String poolcapacity, String peaklimit) {
		String destinationName = customer.trim() + sid.trim() + client.trim();
		Map<String, Map<String, String>> systems = customerSystemKeys.getOrDefault(customer,
				new HashMap<String, Map<String, String>>());
		customerSystemKeys.put(customer, systems);
		Map<String, String> clients = systems.getOrDefault(sid, new HashMap<String, String>());
		systems.put(sid, clients);
		clients.put(client, destinationName);
		Properties props = new Properties();
		props.setProperty(DestinationDataProvider.JCO_ASHOST, ashost);
		props.setProperty(DestinationDataProvider.JCO_SYSNR, sysnr);
		props.setProperty(DestinationDataProvider.JCO_CLIENT, client);
		props.setProperty(DestinationDataProvider.JCO_USER, user);
		props.setProperty(DestinationDataProvider.JCO_PASSWD, password);
		props.setProperty(DestinationDataProvider.JCO_LANG, lang);
		props.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, poolcapacity);
		props.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, peaklimit);
		addDestination(destinationName, props);
	}

	public Properties getDestinationProperties(String destinationName) {
		if (propertiesForDestinationName.containsKey(destinationName)) {
			return propertiesForDestinationName.get(destinationName);
		} else {
			throw new RuntimeException("JCo destination not found: " + destinationName);
		}
	}

	public boolean hasDestination(String customer, String systemid, String client) {
		String destinationName = getDestinationName(customer, systemid, client);
		if (destinationName != null && destinationName.length() > 0)
			return true;
		else
			return false;
	}

	public JCoDestination getDestination(String customer, String systemid, String client) {
		String destinationName = getDestinationName(customer, systemid, client);
		try {
			return JCoDestinationManager.getDestination(destinationName);
		} catch (JCoException e) {
			e.printStackTrace();
		}
		return null;
	}

	private String getDestinationName(String customer, String systemid, String client) {
		return customerSystemKeys.get(customer).get(systemid).get(client);
	}

	/**
	 * Delete destination.
	 *
	 * @param destinationName
	 *            the destination name
	 */
	public void deleteDestination(String destinationName) {
		propertiesForDestinationName.remove(destinationName);
		eventListener.deleted(destinationName);
	}

	public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
		this.eventListener = eventListener;
	}

	public boolean supportsEvents() {
		return true;
	}
}