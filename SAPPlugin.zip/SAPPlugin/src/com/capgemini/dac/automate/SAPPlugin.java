package com.capgemini.dac.automate;

import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.sap.conn.jco.*;

// TODO: Auto-generated Javadoc
/**
 * This gives user accesss to SAP Environment.
 *
 * @author sahana.b.s@capgemini.com
 */
public class SAPPlugin implements UserManagementPlugin {

	/** The client systems. */
	private DataProvider clientSystems;

	/** The central service. */
	private CentralServices centralService;

	/** The version. */
	private String version;

	/** The environment tag. */
	private String environmentTag;

	/** The add to response map. */
	static Map<String, String> addToResponseMap = new HashMap<>();

	/** The environments. */
	ArrayList<EnvironmentParameters> environments = new ArrayList<EnvironmentParameters>();

	/**
	 * Instantiates a new SAP plugin.
	 */
	public SAPPlugin() {
		clientSystems = DataProvider.getInstance();
	}

	/**
	 * Instantiates a new SAP plugin.
	 *
	 * @param centralServices
	 *            the central services
	 */
	public SAPPlugin(CentralServices centralServices) {
		clientSystems = DataProvider.getInstance();
		this.setCentralServices(centralServices);

	}

	/**
	 * Sets the central services.
	 *
	 * @param centralServices
	 *            the new central services
	 */
	public void setCentralServices(CentralServices centralServices) {
		this.centralService = centralServices;

	}

	public String getUser() {
		return environmentTag;
	}

	/**
	 * Load configuration.
	 */
	public void loadConfiguration() {
		String configurationFile = this.centralService.getConfigFilename("SAPPlugin");
		JSONParser jsonParser = new JSONParser();
		try {
			JSONObject jasonobj = (JSONObject) jsonParser.parse(new FileReader(configurationFile));
			JSONObject sapConfig = (JSONObject) jasonobj.get("SAPPlugin");
			if (sapConfig == null) {
				JSONObject plugins = (JSONObject) jasonobj.get("plugins");
				sapConfig = (JSONObject) plugins.get("SAPPlugin");
			}
			this.environmentTag = (String) sapConfig.get("environment_name");
			this.version = (String) sapConfig.get("version");
			JSONArray clients = (JSONArray) sapConfig.get("clients");
			Iterator<?> iterator = clients.iterator();
			while (iterator.hasNext()) {
				JSONObject client = (JSONObject) iterator.next();
				client.get("landscapes");
				String filename = (String) client.get("config_file");
				if (filename != null) {
					try {
						client = (JSONObject) jsonParser.parse(new FileReader(filename));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				this.parseClientConfiguration(client);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Parses the client configuration.
	 *
	 * @param client
	 *            the client
	 */
	private void parseClientConfiguration(JSONObject client) {
		String name = client.get("name").toString();
		JSONArray landscapes = (JSONArray) client.get("landscapes");
		Iterator<?> iterator = landscapes.iterator();
		while (iterator.hasNext()) {
			JSONObject jsonObject = (JSONObject) iterator.next();
			String filename = (String) jsonObject.get("config_file");
			if (filename != null) {
				JSONParser jsonParser = new JSONParser();
				try {
					jsonObject = (JSONObject) jsonParser.parse(new FileReader(filename));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			clientSystems.addDestination(name, jsonObject.get("sid").toString(), jsonObject.get("host").toString(),
					jsonObject.get("SYSNR").toString(), jsonObject.get("client").toString(),
					jsonObject.get("user").toString(), jsonObject.get("password").toString(),
					jsonObject.get("LANG").toString());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#initialize(com.capgemini.dac.
	 * automate.CentralServices)
	 */
	/*
	 * Used to set the Central services class
	 */
	public void initialize(CentralServices centralServices) {
		this.setCentralServices(centralServices);
		this.loadConfiguration();
		this.centralService.registerUserManagementPlugin("SAPPlugin", environmentTag, version, this);
	}

	/*
	 * Used to create user
	 * 
	 */
	public ResultsBlock createUser(Parameters parameters) {
		ResultsBlock results = new ResultsBlock();
		String password = new PasswordGenerator(5, 12, true, true, true, false, "").generate(8);
		String functionName = "BAPI_USER_CREATE1";
		String email = parameters.getField("email");
		String userId = parameters.getField("id");
		String validFrom = parameters.getField("start_date");
		String validTo = parameters.getField("end_date");
		results.mergeResults(validateParameters(parameters));
		String requestID = parameters.getField("RequestID");
		JCoFunction function = null;
		SimpleDateFormat targetDate = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDate;

		Date toDate;
		String body = null;

		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {
					fromDate = targetDate.parse(validFrom);
					toDate = targetDate.parse(validTo);
					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userId);
					function.getImportParameterList().getStructure("NAME_IN").setValue("BAPIBNAME", userId);
					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGV", fromDate);
					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGB", toDate);
					function.getImportParameterList().getStructure("PASSWORD").setValue("BAPIPWD", password);
					function.getImportParameterList().getStructure("ADDRESS").setValue("E_MAIL", email);
					function.execute(destination);
				} catch (JCoException e) {
					e.printStackTrace();
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				} catch (ParseException e1) {
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				}
				JCoTable ldataTable = function.getTableParameterList().getTable("RETURN");
				if (ldataTable.getString("MESSAGE").equalsIgnoreCase("User " + userId + " already exists")) {
					results.addErrorMessage(client, environmentTag, landscape, "User Already Exists");
				}
				password = function.getImportParameterList().getStructure("PASSWORD").getString("BAPIPWD");
				String messageType = null;
				String messageResponse = null;
				String messageText = null;
				if (password.isEmpty()) {
					messageResponse = ldataTable.getString("MESSAGE_V1") + " " + ldataTable.getString("MESSAGE_V2")
							+ " " + ldataTable.getString("MESSAGE_V3") + " " + ldataTable.getString("MESSAGE_V4");
					messageText = ldataTable.getString("MESSAGE");
					messageType = ldataTable.getString("TYPE");
					if (messageType.equals("E") || messageType.equals("A")) {
						results.addErrorMessage(client, environmentTag, landscape,
								"An error occurred while executing the BAPI and the error message is: " + messageText
										+ ". And " + messageResponse);
						return results;
					} else if (messageType.equals("W")) {
						results.addErrorMessage(client, environmentTag, landscape,
								"A warning message appeared: " + messageText + ". And " + messageResponse);
						return results;
					}
				} else {
					if (ldataTable.getString("MESSAGE").equalsIgnoreCase("User " + userId + " already exists")) {
						results.addErrorMessage(client, environmentTag, landscape, ldataTable.getString("MESSAGE"));
						return results;
					} else {
						userRoleAssign(parameters);
						body = "A user has been created for "
								+ parameters.getEnvironmentsOfClientType(client, environmentTag) + " Credentials are:"
								+ "\n" + "UserName : " + parameters.getField("id") + "\n" + "Password : " + password
								+ "\n";
						addToResponseMap.put("client", client);
						addToResponseMap.put("body", body);
						results.addInfoMessage(client, environmentTag, landscape, "User created");
						centralService.addToResponseMail(requestID, addToResponseMap.get("client"),
								addToResponseMap.get("body"), environmentTag);
					}
				}
			}
		}

		return results;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.capgemini.dac.automate.UserManagementPlugin#validateParameters(com.
	 * capgemini.dac.automate.Parameters)
	 */
	/*
	 * Validate Date parametrs
	 *
	 */
	public ResultsBlock validateParameters(Parameters params) {
		ResultsBlock result = new ResultsBlock();
		ValidationFieldsImplementation dao = new ValidationFieldsImplementation();

		ArrayList<String> requiredFields = dao.getRequiredFields();
		for (String name : requiredFields) {
			if (!params.hasField(name)) {
				result.setErrors(true);
				result.addErrorMessage("Global", "Global", "Global", "Missing required field" + name);

			}
		}

		if (params.hasField("start_date")) {
			if (!validateDateParameters(params.getField("start_date")))
				result.addErrorMessage("global", "Global", "global", "Start date is of wrong format");
		}
		if (params.hasField("end_date")) {
			if (!validateDateParameters(params.getField("end_date")))
				result.addErrorMessage("global", "Global", "global", "End date is of wrong format");
		}

		if (params.hasField("customers")) {
			// breaking out customers
			if (!validateCustomers(params.getField("customers")))
				result.addErrorMessage("global", "Global", "global", "Customer does not exist");
		}

		return result;
	}

	/**
	 * Validate customers.
	 *
	 * @param customer
	 *            the customer
	 * @return true, if successful
	 */
	private boolean validateCustomers(String customer) {

		for (EnvironmentParameters temp : environments) {
			if (temp.getClient().equals(customer))
				return true;
		}
		return false;
	}

	/**
	 * Validate date parameters.
	 *
	 * @param dateFields
	 *            the date fields
	 * @return true, if successful
	 */
	private boolean validateDateParameters(String dateFields) {

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

		Date date;

		try {

			date = sdf.parse(dateFields);
			date.toString();

			return true;

		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		return false;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#userRoleAssign(com.capgemini.
	 * dac.automate.Parameters)
	 */
	/*
	 * Assigns Role to User sap_all
	 */
	public ResultsBlock userRoleAssign(Parameters parameters) {
		ResultsBlock results = new ResultsBlock();

		String functionName = "BAPI_USER_PROFILES_ASSIGN";

		String userId = parameters.getField("id");

		JCoFunction function = null;

		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {

					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userId);

					JCoTable table = function.getTableParameterList().getTable("PROFILES");
					if (0 == table.getNumRows()) {
						table.appendRow();
					}
					table.setValue("BAPIPROF", "SAP_ALL");
					function.execute(destination);
					if (0 == table.getNumRows()) {
						table.appendRow();
					}
					for (int i = 0; i < table.getNumRows(); i++) {
						table.setRow(i);
						System.out.println("profile assigned successfully");
					}
				} catch (JCoException e) {
					e.printStackTrace();
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				}
				JCoTable ldataTable = function.getTableParameterList().getTable("RETURN");
				if (ldataTable.getString("MESSAGE").equalsIgnoreCase("User " + userId + " does not exist")) {
					results.addErrorMessage(client, environmentTag, landscape, "User does not Exists");
				}

			}
		}
		return results;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#userUpdate(com.capgemini.dac.
	 * automate.Parameters)
	 */
	/*
	 * Use to updte the user validity period
	 */
	@Override
	public ResultsBlock userUpdate(Parameters parameters) {
		ResultsBlock results = new ResultsBlock();

		String functionName = "BAPI_USER_CHANGE";

		String userId = parameters.getField("id");
		String validFrom = parameters.getField("start_date");
		String validTo = parameters.getField("end_date");
		results.mergeResults(validateParameters(parameters));

		JCoFunction function = null;
		SimpleDateFormat targetDate = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDate;

		Date toDate;

		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {
					fromDate = targetDate.parse(validFrom);
					toDate = targetDate.parse(validTo);
					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userId);

					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGV", fromDate);
					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGB", toDate);
					function.getImportParameterList().getStructure("LOGONDATAX").setValue("GLTGV", "X");
					function.getImportParameterList().getStructure("LOGONDATAX").setValue("GLTGB", "X");
					function.execute(destination);

					JCoTable table = function.getTableParameterList().getTable("RETURN");

					String message = table.getString("MESSAGE");
					if (message.equalsIgnoreCase("User " + userId + " has changed")
							|| message.equalsIgnoreCase("No changes were made to user " + userId)) {
						results.addInfoMessage(client, environmentTag, landscape, "User validity Period Extended");
					} else {
						results.addInfoMessage(client, environmentTag, landscape, message);
					}
				} catch (JCoException e) {
					e.printStackTrace();
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				} catch (ParseException e1) {
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				}
			}
		}
		return results;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#resetPassword(com.capgemini.
	 * dac.automate.Parameters)
	 */
	/*
	 * Resets a password for the user
	 */
	public ResultsBlock resetPassword(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		String functionName = "BAPI_USER_CHANGE";

		String userId = parameters.getField("id");
		String requestID = parameters.getField("RequestID");
		JCoFunction function = null;
		String password = new PasswordGenerator(5, 12, true, true, true, false, "").generate(8);

		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {

					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userId);
					function.getImportParameterList().getStructure("PASSWORD").setValue("BAPIPWD", password);
					function.getImportParameterList().getStructure("PASSWORDX").setValue("BAPIPWD", "X");
					function.execute(destination);

					JCoTable table = function.getTableParameterList().getTable("RETURN");

					if (table.getString("MESSAGE").equalsIgnoreCase("User " + userId + " does not exist")) {
						result.addInfoMessage(client, environmentTag, landscape, " User Doesnt exist ");
					} else {
						result.addInfoMessage(client, environmentTag, landscape, "User Password Reset");
						String body = "Password has been reset for your ID "
								+ parameters.getEnvironmentsOfClientType(client, environmentTag) + " Credentials are:"
								+ "\n" + "UserName : " + parameters.getField("id") + "\n" + "Password : " + password
								+ "\n";
						addToResponseMap.put("client", client);
						addToResponseMap.put("body", body);
						result.addInfoMessage(client, environmentTag, landscape, "User Password Reset");
						centralService.addToResponseMail(requestID, addToResponseMap.get("client"),
								addToResponseMap.get("body"), environmentTag);
					}
				} catch (JCoException e) {
					e.printStackTrace();
					result.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				}
			}

		}
		return result;
	}

	

	/*
	 * Extend the validity period of the user
	 */
	@Override
	public ResultsBlock extendValidity(Parameters parameters) {

		ResultsBlock results = new ResultsBlock();

		String functionName = "BAPI_USER_CHANGE";

		String userId = parameters.getField("id");
		String validFrom = parameters.getField("start_date");
		String validTo = parameters.getField("end_date");
		results.mergeResults(validateParameters(parameters));

		JCoFunction function = null;
		SimpleDateFormat targetDate = new SimpleDateFormat("yyyy-MM-dd");

		Date fromDate;

		Date toDate;

		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {
					fromDate = targetDate.parse(validFrom);
					toDate = targetDate.parse(validTo);
					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userId);

					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGV", fromDate);
					function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGB", toDate);
					function.getImportParameterList().getStructure("LOGONDATAX").setValue("GLTGV", "X");
					function.getImportParameterList().getStructure("LOGONDATAX").setValue("GLTGB", "X");
					function.execute(destination);

					JCoTable table = function.getTableParameterList().getTable("RETURN");

					String message = table.getString("MESSAGE");
					if (message.equalsIgnoreCase("User " + userId + " has changed")
							|| message.equalsIgnoreCase("No changes were made to user " + userId)) {
						results.addInfoMessage(client, environmentTag, landscape, "User validity Period Extended");
					} else {
						results.addInfoMessage(client, environmentTag, landscape, message);
					}
				} catch (JCoException e) {
					e.printStackTrace();
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				} catch (ParseException e1) {
					results.addErrorMessage(client, environmentTag, landscape,
							"Cannot be parsed as a date,Format required is yyyy-MM-dd");
				}
			}
		}
		return results;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.capgemini.dac.automate.UserManagementPlugin#userDelete(com.capgemini.dac.
	 * automate.Parameters)
	 */
	/*
	 * deletes a user
	 */
	@Override
	public ResultsBlock userDelete(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();

		result.addInfoMessage("DAC", environmentTag, "Test", "User deleted");
		return result;
	}


	/*
	 * Locks a user
	 */
	@Override
	public ResultsBlock lockUser(Parameters parameters) {
		ResultsBlock result = new ResultsBlock();
		String userName = parameters.getField("id");
		String functionName = "BAPI_USER_UNLOCK";
		JCoFunction function = null;
		for (String client : parameters.getClients()) {
			for (String landscape : parameters.getEnvironmentsOfClientType(client, getUser())) {
				String[] landscapeparts = landscape.split(":");
				JCoDestination destination = clientSystems.getDestination(client, landscapeparts[0], landscapeparts[1]);
				try {
					
					function = destination.getRepository().getFunctionTemplate(functionName).getFunction();
					function.getImportParameterList().setValue("USERNAME", userName);

					function.execute(destination);

					JCoTable table = function.getTableParameterList().getTable("RETURN");

					String message = table.getString("MESSAGE");
					if (message.equalsIgnoreCase("User " + userName + " does not exist")
							|| message.equalsIgnoreCase("No changes were made to user " + userName)) {
						result.addInfoMessage(client, environmentTag, landscape, "User unlocked failed");
					} else {
						result.addInfoMessage(client, environmentTag, landscape, "User unlocked");
					}
				} catch (JCoException e) {
					e.printStackTrace();
					result.addErrorMessage(client, environmentTag, landscape,
							"Cannot be unlocked");
				}
			}
		}
		result.addInfoMessage("DAC", environmentTag, "Test", "User unLocked");
		return result;
	}

}
