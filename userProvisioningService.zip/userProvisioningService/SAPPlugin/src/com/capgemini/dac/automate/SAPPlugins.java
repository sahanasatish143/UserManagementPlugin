/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.json.simple.JSONObject;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoFunctionTemplate;
import com.sap.conn.jco.JCoRepository;

import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;

/**
 * This class represents the UserProvisioningService SAP plugin code.
 *
 * @author Sahana S; sahana.b.s@capgemini.com
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 */
public class SAPPlugins implements UserManagementPlugin {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SAPPlugins.class.getName());

	/** The destination name. */
	static String destinationName = "SAPSystem";

	/** The destination. */
	static JCoDestination destination;

	/** The sap repository. */
	static JCoRepository sapRepository;

	/** The template. */
	static JCoFunctionTemplate template;

	/** The hash map. */
	static Map<String, String> hashMap = new HashMap<>();

	/** The hash map value. */
	static Map<String, String> hashMapValue = new HashMap<>();

	/** The json. */
	static JSONObject json = new JSONObject();

	/** The sub. */
	static String sub;

	/** The message string. */
	static String msg;

	/** The to. */
	static String to;

	/** The password. */
	static String thePassword;

	static String environment;

	/** The jsonrsponse from SAP */
	static String jsonresponse;

	/**
	 * This method is an unimplemented plugin method where we will be having in the
	 * SAP interface level.
	 *
	 * @return the user
	 */
	@Override
	public String getUser() {
		return "SAP";
	}

	/**
	 * Geek password. This our Password generating method We have use static here,
	 * so that we need not make any object for it
	 * 
	 * @return the string
	 */
	static String geek_Password() {
		int MAX_LENGTH = 16;
		String DIGITS = "23456789";
		String LOCASE_CHARACTERS = "abcdefghjkmnpqrstuvwxyz";
		String UPCASE_CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZ";
		String SYMBOLS = "@#$%=:?";
		String ALL = DIGITS + LOCASE_CHARACTERS + UPCASE_CHARACTERS + SYMBOLS;
		char[] upcaseArray = UPCASE_CHARACTERS.toCharArray();
		char[] locaseArray = LOCASE_CHARACTERS.toCharArray();
		char[] digitsArray = DIGITS.toCharArray();
		char[] symbolsArray = SYMBOLS.toCharArray();
		char[] allArray = ALL.toCharArray();
		Random r = new Random();

		StringBuilder sb = new StringBuilder();

		// get at least one lowercase letter
		sb.append(locaseArray[r.nextInt(locaseArray.length)]);

		// get at least one uppercase letter
		sb.append(upcaseArray[r.nextInt(upcaseArray.length)]);

		// get at least one digit
		sb.append(digitsArray[r.nextInt(digitsArray.length)]);

		// get at least one symbol
		sb.append(symbolsArray[r.nextInt(symbolsArray.length)]);

		// fill in remaining with random letters
		for (int i = 0; i < MAX_LENGTH - 4; i++) {
			sb.append(allArray[r.nextInt(allArray.length)]);
		}

		return sb.toString();
	}

	/**
	 * This plugin method is used for create the SAP User It first logging into the
	 * SAP system through microId user and then create a userId,username with
	 * password.
	 *
	 * @param sapUserName
	 *            is the sap user name
	 * @param name
	 *            the fullname
	 * @param eMail
	 *            the e mail
	 * @return the creates the user SAP
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String createUser(Map<String, Object> pluginParams, Map<String, String> envParams) {
		String thePassword = geek_Password();
		String functionName = "BAPI_USER_CREATE1";
		String validFrom = (String) pluginParams.get("ValidFrom");
		String userId = (String) pluginParams.get("UserId");
		String validTo = (String) pluginParams.get("ValidTo");
		String eMail = (String) pluginParams.get("EMAIL");
		// String firstname = (String) pluginParams.get("FirstName");
		String environment = envParams.get("Environment");
		DateFormat targetDate = new SimpleDateFormat("yyyy-MM-dd");
        String fromDate = targetDate.format(validFrom);
        String toDate = targetDate.format(validTo);
        

		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			// Singleton method to initialize the SAP destination provider only once per JVM
			
			
			SAPInitSingleton.getInstance(destinationName);
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			JCoRepository sapRepository = destination.getRepository();
			// BAPI USED TO CHECK whether the created user exists or not

			

			template = sapRepository.getFunctionTemplate(functionName);
			JCoFunction function = template.getFunction();
			function.getImportParameterList().setValue("USERNAME", userId);
			function.getImportParameterList().getStructure("NAME_IN").setValue("BAPIBNAME", userId);
			function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGV", fromDate);
			function.getImportParameterList().getStructure("LOGONDATA").setValue("GLTGB", toDate);
			function.getImportParameterList().getStructure("PASSWORD").setValue("BAPIPWD", thePassword);
			function.getImportParameterList().getStructure("ADDRESS").setValue("E_MAIL", eMail);
			to = (String) function.getImportParameterList().getStructure("ADDRESS").getValue("E_MAIL");
			function.execute(destination);
			JCoTable ldataTable = function.getTableParameterList().getTable("RETURN");
			if (ldataTable.getString("MESSAGE").equalsIgnoreCase("User " + userId + " already exists")) {
				logger.info("user already existss");
			}
			thePassword = function.getImportParameterList().getStructure("PASSWORD").getString("BAPIPWD");
			String messageType = null;
			String messageResponse = null;
			String messageText = null;
			HashMap<String, String> map = new HashMap<String, String>();
			if (thePassword.isEmpty()) {
				messageResponse = ldataTable.getString("MESSAGE_V1") + " " + ldataTable.getString("MESSAGE_V2") + " "
						+ ldataTable.getString("MESSAGE_V3") + " " + ldataTable.getString("MESSAGE_V4");
				messageText = ldataTable.getString("MESSAGE");
				messageType = ldataTable.getString("TYPE");
				if (messageType.equals("E") || messageType.equals("A")) {
					map.put("Error Message", "An error occurred while executing the BAPI and the error message is: "
							+ messageText + ". And " + messageResponse);
					map.put("Environment ", environment);
					json.putAll(map);
					return json.toString();
				} else if (messageType.equals("W")) {
					map.put("Warning Message",
							"A warning message appeared: " + messageText + ". And " + messageResponse);
					map.put("Environment ", environment);
					json.putAll(map);
					return json.toString();
				}
			} else {
				if (ldataTable.getString("MESSAGE").equalsIgnoreCase("User " + userId + " already exists")) {
					map.put("Response ", ldataTable.getString("MESSAGE"));
					map.put("Environment ", environment);
					json.putAll(map);
					return json.toString();
				} else {
					// send mail notification
					userRoleAssign(pluginParams, envParams);
					sub = "SAP User Credentials";
					msg = "Hello User,\r\n" + "\r\n" + "User has been created for your credentials. " + "\r\n"
							+ "Username is: " + userId + "\r\n" + "Password is: " + thePassword + "\r\n" + "\r\n"
							+ "Thanks,\r\n " + "\r\n" + "SAP Support";
					sendEmail(userId, thePassword, eMail, sub, msg);

					map.put("Response ", ldataTable.getString("MESSAGE"));
					map.put("Environment ", environment);

					json.putAll(map);

					return json.toString();
				}
			}
			return json.toString();
		} catch (JCoException  e) {
			e.printStackTrace();
			logger.severe(e.getMessage());
			hashMap.put("Response ", "Cannot be parsed as a date,Format required is yyyy-MM-dd");
			hashMap.put("Environment ", environment);
		}
		return "";
	}

	/**
	 * This plugin method is used for change the password for created userid of SAP
	 * User It first logging into the SAP system through microId user and change the
	 * password. sapUserId-is the username whose passord you want to change
	 * sapPassword-is the new sap password
	 *
	 * @param sapUserId
	 *            the sap user id
	 * @return the string
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String resetPassword(Map<String, Object> pluginParams, Map<String, String> envParams) {
		String newPassword = geek_Password();
		String functionName = "BAPI_USER_CHANGE";
		String userId = (String) pluginParams.get("UserId");
		try {
			// Singleton method to initialize the SAP destination provider only once per JVM
			SAPInitSingleton.getInstance(destinationName);
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			JCoRepository sapRepository = destination.getRepository();
			// BAPI USED TO CHECK whether the created user exists or not
			template = sapRepository.getFunctionTemplate(functionName);
			JCoFunction function = template.getFunction();
			// setting the new password for existing user and executing the BAPI
			function.getImportParameterList().setValue("USERNAME", userId);
			function.getImportParameterList().getStructure("PASSWORD").setValue("BAPIPWD", newPassword);
			function.getImportParameterList().getStructure("PASSWORDX").setValue("BAPIPWD", "X");
			function.execute(destination);
			JCoTable ldata = (JCoTable) function.getTableParameterList().getTable("RETURN");
			SAPPlugins test = new SAPPlugins();
			Map<String, String> myMap = new HashMap<String, String>();
			String value = test.userInfo(pluginParams, envParams);
			value = value.substring(1, value.length() - 1);
			String[] pairs = value.split(",");
			// iterate over the pairs
			for (String pair : pairs) {
				// split the pairs to get key and value
				String[] entry = pair.split("=");
				// add them to the hashmap and trim whitespaces
				myMap.put(entry[0].trim(), entry[1].trim());
			}

			if (ldata.getString("MESSAGE").equalsIgnoreCase("User " + userId + " does not exist")) {
				Map<String, String> map = new HashMap<String, String>();
				map.put("Response ", ldata.getString("MESSAGE"));
				map.put("Environment ", environment);
				json.putAll(map);
				return json.toString();
			} else {
				// send mail notification
				String eMail = myMap.get("EMAIL");
				logger.info("the  new mail id is " + eMail);
				sub = "Password Reset";
				msg = "Hello User,\r\n" + "\r\n" + "Password has been reset for your ID: " + userId + "." + "\r\n"
						+ "The new password is: " + newPassword + "\r\n" + "\r\n" + "Thanks,\r\n " + "\r\n"
						+ "SAP Support";
				sendEmail(userId, newPassword, eMail, sub, msg);
				Map<String, String> map = new HashMap<String, String>();
				map.put("Response ", ldata.getString("MESSAGE"));
				map.put("Environment ", environment);
				json.putAll(map);
				return json.toString();
			}
		} catch (JCoException e) {
			e.printStackTrace();
			logger.severe(e.getMessage());
		}
		return json.toString();
	}

	/**
	 * This plugin method which is used to check for existing user. The method logs
	 * on to SAP as a service account user and executes the command returning a
	 * string indicating whether the user exists or not.
	 *
	 * @param userName
	 *            the user name
	 * @return A message with whether user exists or not
	 */
	@SuppressWarnings("unchecked")
	@Override
	public String userInfo(Map<String, Object> pluginParams, Map<String, String> envParams) {
		String functionName = "BAPI_USER_GET_DETAIL";
		String userName = (String) pluginParams.get("UserId");
		try {
			// Singleton method to initialize the SAP destination provider only once per JVM
			SAPInitSingleton.getInstance(destinationName);
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			JCoRepository sapRepository = destination.getRepository();

			// BAPI USED TO CHECK whether the created user exists or not
			template = sapRepository.getFunctionTemplate(functionName);
			JCoFunction function = template.getFunction();
			function.getImportParameterList().setValue("USERNAME", userName);
			function.getImportParameterList().setValue("CACHE_RESULTS", " ");
			function.execute(destination);
			String eMail = function.getExportParameterList().getStructure("ADDRESS").getString("E_MAIL");
			String validFrom = function.getExportParameterList().getStructure("LOGONDATA").getString("GLTGV");
			String validTo = function.getExportParameterList().getStructure("LOGONDATA").getString("GLTGB");
			JCoTable ldataTable = (JCoTable) function.getTableParameterList().getTable("RETURN");

			if (ldataTable.isEmpty()) {
				hashMapValue.put("UserId ", userName);
				hashMapValue.put("EMAIL", eMail);
				hashMapValue.put("ValidFrom ", validFrom);
				hashMapValue.put("ValidTo ", validTo);
				hashMapValue.put("Environment ", environment);
				hashMapValue.put("Password Status ", "NA");
				return hashMapValue.toString();
			} else {
				Map<String, String> map = new HashMap<String, String>();
				map.put("Response ", ldataTable.getString("MESSAGE"));
				map.put("Environment ", environment);
				json.putAll(map);
				return json.toString();
			}
		} catch (JCoException e) {
			msg = "An error occurred while executing the BAPI and the error message is: " + e.getMessage();
			logger.severe(msg);
			e.printStackTrace();
		}
		return "";
	}

	/*
	 * The following lines of code invode user deletion
	 */
	@SuppressWarnings({ "unchecked", "unused" })
	@Override
	public String userDeletion(Map<String, Object> pluginParams, Map<String, String> envParams) {
		String functionName = "BAPI_USER_DELETE";
		JSONObject jsonObj = new JSONObject();
		String userId = (String) pluginParams.get("UserId");
		try {
			// Singleton method to initialize the SAP destination provider only once per JVM
			SAPInitSingleton.getInstance(destinationName);
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			JCoRepository sapRepository = destination.getRepository();
			Map<String, String> hash_Map = new HashMap<>();
			ArrayList<String> table = new ArrayList<>();
			// BAPI USED TO CHECK whether the created user exists or not
			template = sapRepository.getFunctionTemplate(functionName);
			JCoFunction function = template.getFunction();
			function.getImportParameterList().setValue("USERNAME", userId);
			function.execute(destination);
			JCoTable ldataTable = (JCoTable) function.getTableParameterList().getTable("RETURN");
			if (ldataTable.isEmpty()) {
				hashMap.put("Response ", "Please enter a userid");
				hashMap.put("Environment ", environment);
				jsonObj.putAll(hashMap);
				return jsonObj.toString();
			} else {

				for (int i = 0; i < ldataTable.getNumRows(); i++) {
					ldataTable.setRow(i);
					table.add(ldataTable.getString("MESSAGE"));
					logger.info(table.toString());
					String msgSap = ldataTable.getString("MESSAGE");
					logger.info(msg);
					hash_Map.put("Response ", "User Deleted");
					hash_Map.put("Environment ", environment);
					jsonObj.putAll(hash_Map);
					return jsonObj.toString();
				}

			}
		} catch (JCoException e) {
			msg = "An error occurred while executing the BAPI and the error message is: " + e.getMessage();
			logger.severe(msg);
			e.printStackTrace();
		}
		return jsonObj.toString();
	}

	/*
	 * UserRole is assigned here with userId, roleAssigned, fromDate, toDate,
	 * description
	 */
	@SuppressWarnings("unchecked")
	public String userRoleAssign(Map<String, Object> pluginParams, Map<String, String> envParams) {
		String functionName = "BAPI_USER_ACTGROUPS_ASSIGN";
		String userId = (String) pluginParams.get("UserId");
		try {
			// Singleton method to initialize the SAP destination provider only once per JVM
			SAPInitSingleton.getInstance(destinationName);
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			JCoRepository sapRepository = destination.getRepository();

			// BAPI USED TO CHECK whether the created user exists or not
			template = sapRepository.getFunctionTemplate(functionName);
			JCoFunction function = template.getFunction();
			function.getImportParameterList().setValue("USERNAME", userId);
			JCoTable table = function.getTableParameterList().getTable("ACTIVITYGROUPS");
			// logger.info(table.getNumRows());
			if (0 == table.getNumRows()) {
				table.appendRow();
			}

			String roleAssigned = (String) pluginParams.get("Role");

			table.setValue("AGR_NAME", roleAssigned);

			// table.appendRow();
			function.execute(destination);
			if (0 == table.getNumRows()) {
				table.appendRow();
			}
			JCoTable ldata1 = function.getTableParameterList().getTable("ACTIVITYGROUPS");
			Map<String, String> hashMapRole = new HashMap<>();
			for (int i = 0; i < ldata1.getNumRows(); i++) {
				ldata1.setRow(i);
				hashMapRole.put("Environment ", environment);
				hashMapRole.put("Role ", ldata1.getString("AGR_NAME"));
				hashMapRole.put("Role Description ", ldata1.getString("AGR_TEXT"));
			}
			json.putAll(hashMapRole);
			return json.toString();
		} catch (JCoException e) {
			e.printStackTrace();
			logger.info("Execution on destination " + destination + " failed");
			logger.severe("EEROR:" + e.getMessage());
			logger.severe("Execution on destination " + destination + " failed");
			hashMap.put("Response ", "Cannot be parsed as a date,Format required is yyyy-MM-dd");
			hashMap.put("Environment ", environment);
		}
		return "";
	}

	/**
	 * This method is to take the configuration details of SAP from a configuration
	 * file. configuration parameters are: ASHost - which resembles the IP address,
	 * USER - which resembles the userName, CLIENT - which resembles the client,
	 * PASSWORD - which resembles the password, SYSNR - which resembles the system
	 * number of the SAPO instance, LANG - Which resembles the language.
	 *
	 * @return the connection config
	 */
	private static Map<String, String> getConnectionConfig() {
		try {
			Properties connectionProperty = new Properties();
			String configFile = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\SAPParam.properties";
			FileReader fReader = null;
			fReader = new FileReader(configFile);
			try {
				connectionProperty.load(fReader);
			} catch (IOException e) {
				e.printStackTrace();
				logger.severe(e.getMessage());
			}
			hashMap.put("sapASHost", connectionProperty.getProperty("ASHost"));
			hashMap.put("sapCLIENT", connectionProperty.getProperty("CLIENT"));
			hashMap.put("sapUSER", connectionProperty.getProperty("USER"));
			hashMap.put("sapPASSWORD", connectionProperty.getProperty("PASSWORD"));
			hashMap.put("sapSYSNR", connectionProperty.getProperty("SYSNR"));
			hashMap.put("sapLANG", connectionProperty.getProperty("LANG"));
			hashMap.put("EMAIL", connectionProperty.getProperty("EMAIL"));
			hashMap.put("PASSWORDEMAIL", connectionProperty.getProperty("PASSWORDEMAIL"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.severe(e.getMessage());
		}
		return hashMap;
	}

	/**
	 * Send email.
	 *
	 * @param sapUserName
	 *            the sap user name
	 * @param thePassword
	 *            the the password
	 * @param eMail
	 *            the e mail
	 * @param sub
	 *            the sub
	 * @param msg
	 *            the msg
	 */
	private void sendEmail(String sapUserName, String thePassword, String eMail, String sub, String msg) {
		final String from = hashMap.get("EMAIL");// testmailid
		final String password = hashMap.get("PASSWORDEMAIL"); // testpwd
		logger.info(from + "email");
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "outlook.office365.com");
		props.put("mail.smtp.port", "587");
		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(from, password);
			}
		});

		// Compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(eMail));

			message.setSubject(sub);
			message.setText(msg);
			// send the message
			Transport.send(message);
			logger.info("message sent successfully...");
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Gets the destination properties.
	 *
	 * @return the destination properties
	 */
	static Properties getDestinationProperties() {
		Map<String, String> connectionConfiguration = null;
		connectionConfiguration = getConnectionConfig();
		// Reading the configuration details for logging into SAP system from the
		// connectionConfiguration.
		String host = connectionConfiguration.get("sapASHost");
		String password = connectionConfiguration.get("sapPASSWORD");
		String client = connectionConfiguration.get("sapCLIENT");
		String user = connectionConfiguration.get("sapUSER");
		String sysnr = connectionConfiguration.get("sapSYSNR");
		String language = connectionConfiguration.get("sapLANG");
		logger.info(host);
		logger.info("ASHost" + host);
		logger.info(client);
		logger.info("CLIENT" + client);
		logger.info(user);
		logger.info("USER" + user);
		logger.info(sysnr);
		logger.info("SYSNR" + sysnr);
		logger.info(language);
		logger.info("LANG" + language);
		logger.info("It is working normally");
		// adapt parameters in order to configure a valid destination
		Properties connectionProperty = new Properties();
		connectionProperty.setProperty(DestinationDataProvider.JCO_ASHOST, host);
		connectionProperty.setProperty(DestinationDataProvider.JCO_CLIENT, client);
		connectionProperty.setProperty(DestinationDataProvider.JCO_USER, user);
		connectionProperty.setProperty(DestinationDataProvider.JCO_PASSWD, password);
		connectionProperty.setProperty(DestinationDataProvider.JCO_SYSNR, sysnr);
		connectionProperty.setProperty(DestinationDataProvider.JCO_LANG, language);
		return connectionProperty;
	}

	/**
	 * The dummy main method for jar export. Used for testing purpoe only
	 * 
	 * @param args
	 *            the arguments
	 * @throws JCoException
	 *             the j co exception
	 */
	public static void main(String[] args) throws JCoException {
		// SAPPlugins test = new SAPPlugins();
		// String ret = test.userRoleAssign("testuser5", "admin", "2020-07-29",
		// "2020-08-29", "THIS IS A ADMIN ROLE");
		// logger.info("Got" + ret);
	}

	@SuppressWarnings("unchecked")
	@Override
	public String updateUser(Map<String, Object> arg0, Map<String, String> arg1) {
		hashMap.put("Environment ", environment);
		hashMap.put("Response", "user updated");
		json.putAll(hashMap);
		return json.toString();
	}

}
