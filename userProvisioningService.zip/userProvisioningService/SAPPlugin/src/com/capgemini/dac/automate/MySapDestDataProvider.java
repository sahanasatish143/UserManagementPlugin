/*
 *  Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate;

import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import com.sap.conn.jco.ext.DestinationDataEventListener;
import com.sap.conn.jco.ext.DestinationDataProvider;

/**
 * The Class MySapDestDataProvider demonstrates a simple 
 * implementation of the DestinationDataProvider interface and shows how
 * to register it. A real world implementation should save the configuration data in a secure way.
 * provides an implementation for at least getDestinationProperties(String).
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 */
public class MySapDestDataProvider implements DestinationDataProvider
{

  /** The properties for destination name. */
  private Map<String, Properties> propertiesForDestinationName = new Hashtable<String, Properties>();
  
  /** The event listener. */
  private DestinationDataEventListener eventListener;
  
  /**
   * Default constructor.
   * Instantiates a new my sap dest data provider.
   */
  public MySapDestDataProvider()
  {
  }
  
  /**
   * Adds the destination.
   *
   * @param destinationName the destination name
   * @param properties the properties
   */
  public void addDestination(String destinationName, Properties properties)
  {
    propertiesForDestinationName.put(destinationName, properties);
    eventListener.updated(destinationName);
  }

  /* Whenever possible the implementation should support events and notify the JCo runtime
   * if a destination is being created, changed, or deleted. Otherwise JCo runtime
   * will check regularly if a cached destination configuration is still valid which incurs
   * a performance penalty.
   */
  public Properties getDestinationProperties(String destinationName)
  {
    if (propertiesForDestinationName.containsKey(destinationName))
    {
      return propertiesForDestinationName.get(destinationName);
    } 
    else
    {
       throw  new RuntimeException("JCo destination not found: "+ destinationName);
    }
  }
  
  /**
   * Delete destination.
   *
   * @param destinationName the destination name
   */
  public void deleteDestination(String destinationName)
  {
    propertiesForDestinationName.remove(destinationName);
    eventListener.deleted(destinationName);
  }

  /* An implementation supporting events has to retain the eventListener instance provided
   * by the JCo runtime. This listener instance shall be used to notify the JCo runtime
   * about all changes in destination configurations.
   */
  public void setDestinationDataEventListener(DestinationDataEventListener eventListener)
  {
    this.eventListener = eventListener;
  }

  /* (non-Javadoc)
   * @see com.sap.conn.jco.ext.DestinationDataProvider#supportsEvents()
   */
  public boolean supportsEvents()
  {
    return true;
  }
}