/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package sample;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

/**
 * This class represents the UserProvisioningService of ActiveDirectoryPlugins.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 */
public class ActiveDirectoryPlugins {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ActiveDirectoryPlugins.class.getName());

	/** The hash map. */
	static Map<String, String> hashMap = new HashMap<>();

	/** The hash map value. */
	static Map<String, String> hashMapValue = new HashMap<>();

	/** The ldap context. */
	DirContext ldapContext;

	/** The jsonrsponse from AD. */
	static String jsonresponse;

	/** The ctx. */
	LdapContext ctx = null;

	
	@SuppressWarnings("unused")
	public String userRoleAssign() throws NamingException {
		getLdapContext();
		Map<String, String> connectionConfiguration = null;

		connectionConfiguration = getConnectionConfig();
		String searchBase = "CN=Users,DC=cgdevops,DC=aws,DC=capamlab,DC=com";
		// String userId = (String) pluginParams.get("UserId");
		String result = "";
		String filter = "(&(objectClass=group)(cn=DnsAdmins))";

		try {
			NamingEnumeration<SearchResult> searchResults = ctx.search(searchBase, filter, null);
			if (searchResults.hasMore()) {
				result = searchResults.next().getNameInNamespace();
				if (searchResults.hasMore()) {
					result = "More than one group has the name " + "DnsAdmins";
					System.out.println(result);
				}
			} else {
				result = "Group " + "DnsAdmins" + " could not be found";
				System.out.println(result);
			}
		} catch (NamingException e) {
			System.err.println("Problem listing membership: " + e);
		}
		return filter;

	}

	/**
	 * Gets the ldap context.
	 *
	 * @return the ldap context
	 */
	public LdapContext getLdapContext() {

		try {
			Map<String, String> connectionConfiguration = null;
			connectionConfiguration = getConnectionConfig();

			String contextFactory = connectionConfiguration.get("INITIALCONTEXTFACTORY");
			String password = connectionConfiguration.get("PASSWORD");
			String user = connectionConfiguration.get("USER");
			String sysnr = connectionConfiguration.get("SECURITY_AUTHENTICATION");
			String url = connectionConfiguration.get("PROVIDER_URL");
			Hashtable<String, String> env = new Hashtable<String, String>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
			env.put(Context.SECURITY_AUTHENTICATION, sysnr);
			env.put(Context.SECURITY_PRINCIPAL, user);// input user & password for access to ldap
			env.put(Context.SECURITY_CREDENTIALS, password);
			env.put(Context.PROVIDER_URL, url);
			System.out.println("Attempting to Connect...");

			ctx = new InitialLdapContext(env, null);
			System.out.println("Connection Successful.");
		} catch (NamingException nex) {
			System.out.println("LDAP Connection: FAILED");
			nex.printStackTrace();
		}
		return ctx;
	}

	/**
	 * This method is to take the configuration details of Active Directory from a
	 * configuration file. configuration parameters are: USER - which resembles the
	 * userName, PASSWORD - which resembles the password,
	 * 
	 *
	 * @return the connection config
	 */
	private static Map<String, String> getConnectionConfig() {
		try {
			Properties connectionProperty = new Properties();
			String configFile = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\ActiveDirectory.properties";
			FileReader fReader = null;
			fReader = new FileReader(configFile);
			try {
				connectionProperty.load(fReader);
			} catch (IOException e) {
				e.printStackTrace();
				logger.severe(e.getMessage());
			}
			hashMap.put("INITIALCONTEXTFACTORY", connectionProperty.getProperty("INITIAL_CONTEXT_FACTORY"));
			hashMap.put("USER", connectionProperty.getProperty("USER"));
			hashMap.put("PASSWORD", connectionProperty.getProperty("PASSWORD"));
			hashMap.put("SECURITY_AUTHENTICATION", connectionProperty.getProperty("SECURITY_AUTHENTICATION"));
			hashMap.put("PROVIDER_URL", connectionProperty.getProperty("PROVIDER_URL"));
			hashMap.put("EMAIL", connectionProperty.getProperty("EMAIL"));
			hashMap.put("PASSWORDEMAIL", connectionProperty.getProperty("PASSWORDEMAIL"));
			hashMap.put("SEARCH_BASE", connectionProperty.getProperty("SEARCH_BASE"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.severe(e.getMessage());
		}
		return hashMap;
	}

	public static void main(String[] args) throws NamingException {
		// System.out.println("hi");
		ActiveDirectoryPlugins test = new ActiveDirectoryPlugins();

		test.userRoleAssign();

	}

}
