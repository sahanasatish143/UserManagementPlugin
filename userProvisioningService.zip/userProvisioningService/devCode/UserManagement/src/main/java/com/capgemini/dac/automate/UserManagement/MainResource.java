/*
 * Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.UserManagement;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import com.networknt.schema.ValidationMessage;

/**
 * The Class MainResource. This class represents the main class of the web
 * service. In this class we accept web request as input parameters and we
 * invoke different plugins (functionality) in the SAP/oracle system.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 */

@Path("/usermanagement")
public class MainResource {

	/** The Constant CONFIGURATION_FILE_PATH. */
	private static final String CONFIGURATION_FILE_PATH = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\userProvisioning.properties";

	/** The plugin manager. */
	private PluginManager pluginManager;
	private Logger logger = Logger.getLogger(MainResource.class.getName());

	/** The response from plugin. */
	static String responsePlugin;

	static String environment;

	/** The hash map value. */
	static Map<String, String> hashMap = new HashMap<>();

	static Map<String, String> gsonMap = new HashMap<String, String>();

	/** The role assigned. */
	static String roleAssigned;

	/** The json. */

	/**
	 * Default constructor. Used for logger initializing and to generate logger
	 * files and Instantiates attributes. code pull changes
	 * 
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public MainResource() throws IOException {
		// set JVM option -DDevelopment=true for development. Logs to console instead of
		// file
		// String isDev = System.getProperty("Development");
		// if (isDev != null) {
		// logger.info("Development mode. Logging to console");
		// Logger.getLogger(MainResource.class.getName());
		// ConsoleHandler consoleHandler = new ConsoleHandler();
		// logger.addHandler(consoleHandler);
		// logger.info("Initialized logger to console.");
		// } else {
		// Used for logger initializing
		try {
			InputStream inputStream = Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("logging.properties");
			LogManager.getLogManager().readConfiguration(inputStream);
			logger.info("Initializing logger");

		} catch (Exception e) {
			logger.info("ERROR: While initializing logger");
			logger.severe("ERROR: While initializing logger");
			e.printStackTrace();
		}
		// }

		Map<String, String> configuration = null;
		try {
			configuration = readProperties();
		} catch (IOException e2) {
			e2.printStackTrace();
			logger.severe(e2.getMessage());
		}
		String path = configuration.get("PATH_TO_PLUGIN_DIRECTORY");
		// load all plugins in plugin directory
		pluginManager = PluginManager.getInstance(path);

		logger.info("plugin loaded");
	}

	/**
	 * Read properties. read the connection properties from property file
	 * 
	 * @return the map
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private Map<String, String> readProperties() throws IOException {
		Map<String, String> map = new HashMap<String, String>();

		try {
			Properties props = new Properties();
			FileReader fReader = null;
			fReader = new FileReader(CONFIGURATION_FILE_PATH);
			props.load(fReader);
			map.put("PATH_TO_PLUGIN_DIRECTORY", props.getProperty("PATH_TO_PLUGIN_DIRECTORY"));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			logger.severe("config file not found");
		}

		return map;
	}

	enum ACTION {
		CREATE, UPDATE, DELETE, RESETPASSWORD, USERINFO
	};

	/**
	 * User Create. if functionality is to create the user with userid,name,email
	 * and generate a random password then invoke the following lines of code
	 * 
	 * @param incomingData
	 *            the incoming data
	 * @return the string
	 * @throws ParseException
	 *             the parse exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	@SuppressWarnings({ "unchecked", "deprecation" })
	@POST
	@Path("/user/create")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	public String createUser(String incomingData) throws ParseException, IOException, java.text.ParseException {
		getDimJSONMap(incomingData);
		JSONObject jsonObj = new JSONObject();
		String schemaStream;

		schemaStream = FileUtils.readFileToString(
				new File("D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\"
						+ "jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\" + "example-schema.json"),
				StandardCharsets.UTF_8);
		ObjectMapper objectMapper = new ObjectMapper();
		JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V201909);

		JsonNode json = objectMapper.readTree(incomingData);
		JsonSchema schema = schemaFactory.getSchema(schemaStream);
		Set<ValidationMessage> validationResult = schema.validate(json);

		// print validation errors
		if (validationResult.isEmpty()) {
			System.out.println("no validation errors :-)");

			
			
				hashMap.put("Response ", " User created ");
				
				hashMap.put("Environment ", "AD");
				jsonObj.putAll(hashMap);
//				JsonParser parser = new JsonParser();
//				JsonElement jsonElement = parser.parse(valid.toString());

				return jsonObj.toString();
			

		} else {
			System.out.println("validation errors :-)");
			List<String> valid=new ArrayList<String>();
			validationResult.forEach(vm -> System.out.println(vm.getMessage()));
			validationResult.forEach(vm ->valid.add(vm.getMessage()));
			System.out.println(valid+ "is the list value");
			hashMap.put("Response ", valid.toString());
			hashMap.put("Environment ", "AD");
			jsonObj.putAll(hashMap);
//			JsonParser parser = new JsonParser();
//			JsonElement jsonElement = parser.parse(valid.toString());

			return jsonObj.toString();
		}
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> getDimJSONMap(String json) {
		Gson gson = new Gson();
		Map<String, Object> map = gson.fromJson(json, Map.class);
		return map;
	}

}
