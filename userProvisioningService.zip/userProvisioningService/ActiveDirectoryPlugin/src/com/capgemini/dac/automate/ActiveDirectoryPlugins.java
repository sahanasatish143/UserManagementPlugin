/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import javax.naming.ldap.StartTlsRequest;
import javax.naming.ldap.StartTlsResponse;

import org.json.simple.JSONObject;

import com.capgemini.dac.automate.UserManagement.CentralServices;
import com.capgemini.dac.automate.UserManagement.Parameters;
import com.capgemini.dac.automate.UserManagement.ResultsBlock;
import com.capgemini.dac.automate.UserManagement.Exception.InvalidPluginArguments;
import com.capgemini.dac.automate.UserManagement.MainResource.ACTION;
//
//import com.capgemini.dac.automate.usermanagement.ClientContext;
//import com.capgemini.dac.automate.usermanagement.ClientEnvironmentConfiguration;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.internal.LinkedTreeMap;

/**
 * This class represents the UserProvisioningService of ActiveDirectoryPlugins.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 */
public class ActiveDirectoryPlugins implements UserManagementPlugin
{
  enum ACTION {
    CREATE,
    UPDATE,
    MODIFY
  };

  /** The Constant logger. */
  private Logger logger;

  /** The hash map. */
  static Map<String, String> hashMap = new HashMap<>();
  static HashMap<String, String> hashMapValid = new HashMap<>();

  /** The hash map value. */
  static Map<String, String> hashMapValue = new HashMap<>();

  /** The ldap context. */
  DirContext ldapContext;

  /** The jsonrsponse from AD. */
  static String jsonresponse;

  /** The ctx. */
  LdapContext ctx = null;
  /** The sub. */
  static String sub;

  /** The message string. */
  static String msg;

  /** The to. */
  static String to;

  /** The Constant FILETIME_EPOCH_DIFF. */
  final static long FILETIME_EPOCH_DIFF = 11644473600000L;

  /**
   * One millisecond expressed in units of 100s of nanoseconds.
   */
  final static long FILETIME_ONE_MILLISECOND = 10 * 1000;
  
  //HashMap<String, ClientContext> clients = new HashMap<String, ClientContext>(); //collection of clients and there configuration
  private String configurationFile = ""; // file where current configuration stuff was loaded from
  private CentralServices centralService = null; // for services needed by all plugins like mail or logging
  private String environmentTag = "active_directory";
  
  public ActiveDirectoryPlugins() {
    
  }
  
  public ActiveDirectoryPlugins(CentralServices centralServices) {
    this.centralService = centralServices;
    this.configurationFile = this.centralService.getConfigFilename("ActiveDirectory");
    this.logger = this.centralService.getLogger();
    centralService.registerUserManagementPlugin("ActiveDirectoryPlugin", "active_directory", "1.0.0", this);
    this.loadConfiguration();
  }
  
  public ActiveDirectoryPlugins(Object centralServices, String filename) {
    
  }
  
  public void loadConfiguration() {
    
  }
  
  public void loadConfiguration(String filename) {
    this.configurationFile = filename;
    this.loadConfiguration();
  }
  
  private HashMap<String, String> cleanAndValidateInputs(ACTION action, Map<String, Object> pluginParams,Map<String, String> envParams) throws InvalidPluginArguments{
    /* verify environment exists
      
       verify basic connection related stuff
       
       create context;
    */
    String environment = envParams.get("Environment");
    if(environment ==null) {
      hashMapValid.put("Response", "Enter a value for environment");
      return hashMapValid;
    }
    if(environment.equalsIgnoreCase("Active Directory")) {
      if (action == ACTION.CREATE) {
        // verify user does not already exist
      }
      else {
        // verify user does exist 
      }
    }
  
    /*
       validate other stuff in the environment
       
       close context
    */
    
    return null;
  }

  /**
   * This method is an unimplemented plugin method where we will be having in the
   * AD interface level.
   *
   * @return the user
   */
  public String getUser()
  {
    return this.environmentTag;
  }

  /**
   * This plugin method is used for create the AD User It first logging into the
   * AD system through adtest user and then creates a new user
   *
   * @param username the username
   * @param givenName the First name
   * @param lastName the last name
   * @param eMail the e mail
   * @param canonicalName is the domain canonical name
   * @return the string
   */
  
  
  @SuppressWarnings({ "unchecked", "rawtypes" })
  public String createUser(Map<String, Object> pluginParams, Map<String, String> envParams)
  {
    HashMap<String, String> inputs = null;
    LdapContext context = null;
//    try {
//      inputs = this.cleanAndValidateInputs(ACTION.CREATE, pluginParams,envParams);
//      context = this.clients.get(inputs.get("Client")).getEnvironmentConfiguration(inputs.get("Client")).getLdapContext();
//    }
//    catch (InvalidPluginArguments e)
//    { 
//      //return information on bad fields and abort call
//    }
    JSONObject json = new JSONObject();
    HashMap<String, Object> map = new HashMap<String, Object>();
    String lastname = (String) pluginParams.get("LastName");
    String dateInString = (String) pluginParams.get("ValidTo");
    String userId = (String) pluginParams.get("UserId");
    // String username = (String) pluginParams.get("UserName");
    String eMail = (String) pluginParams.get("EMAIL");
    String firstname = (String) pluginParams.get("FirstName");
    String environment = envParams.get("Environment");

    System.out.println(envParams + "is the arrayList");

    if (lastname == null || dateInString == null)
    {
      map.put("Response ", "Date and lastname are mandatory");
      json.putAll(map);
      return json.toString();
    }
    // NOTE: replace theUserName below with the Active Directory/LDAP user whose
    // attribites you want printed.
    String password = geek_Password();
    getLdapContext();
    try
    {
      // Create a container set of attributes
      StringBuffer sb = new StringBuffer();
      Map<String, String> connectionConfiguration = null;
      connectionConfiguration = getConnectionConfig();
      String searchBase = connectionConfiguration.get("SEARCH_BASE");
      LdapName subjectDN = new LdapName(searchBase);
      List<Rdn> rdns = subjectDN.getRdns();
      for (int i = rdns.size() - 1; i >= 0; i--)
      {
        final Rdn rds = rdns.get(i);
        final Attributes attributes = rds.toAttributes();
        final Attribute cn = attributes.get("dc");
        if (cn != null)
        {

          final String value = (String) cn.get();
          if (value != null)
          {
            // System.out.println(value);

            String[] a = value.split(",");

            for (int j = 0; j < a.length; j++)
            {
              String segments[] = a[j].split("=");
              String last = segments[segments.length - 1];
              // System.out.println(last);
              sb.append(last).append(".");

            }
          }
        }
      }
      String domainName = sb.toString();
      final Attributes container = new BasicAttributes();

      // Create the objectclass to add
      final Attribute objClasses = new BasicAttribute("objectClass");
      objClasses.add("User");

      // Assign the username, first name, and last name
      final Attribute commonName = new BasicAttribute("cn", userId);
      final Attribute sAMAccountName = new BasicAttribute("sAMAccountName", userId);
      final Attribute email = new BasicAttribute("mail", eMail);
      final Attribute firstName = new BasicAttribute("givenName", firstname);
      final Attribute uid = new BasicAttribute("uid", userId);
      final Attribute surName = new BasicAttribute("sn", lastname);
      final Attribute displayName = new BasicAttribute("displayName", firstName + " " + lastname);
      final Attribute description = new BasicAttribute("description", "demo");
      final Attribute userLogonName = new BasicAttribute("userPrincipalName", userId + "@" + domainName);
      // final Attribute userChangePwd = new BasicAttribute("pwdLastSet", "0");

      SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");

      Date date = sdf.parse(dateInString);
      final long dd = date.getTime();
      final Attribute accountExpires = new BasicAttribute("accountExpires", Long.toString(millisToFiletime(dd)));

      // Add password
      final Attribute userPassword = new BasicAttribute("userpassword", password);

      // Add these to the container
      container.put(objClasses);
      container.put(commonName);
      container.put(firstName);
      container.put(email);
      container.put(uid);
      container.put(surName);
      container.put(userPassword);
      container.put(displayName);
      container.put(description);
      container.put(userLogonName);
      container.put(sAMAccountName);
      container.put(accountExpires);
      // container.put(accEnable);
      // container.put(userChangePwd);

      ctx.createSubcontext(getUserDN(userId), container);

      System.out.println("USER CREATED");
      sub = "AD User Credentials";
      // double remove
      msg = "Hello User,\n\n" + "\n" + "User has been created for your credentials. " + "\n\n" + "Username is: "
          + userId + "\n" + "Password is: " + password + "\n\n" + "Thanks,\n\n" + "AD Support";
      this.centralService.sendEmail(eMail, sub, msg);

      ArrayList<LinkedTreeMap<String, Object>> envList = (ArrayList<LinkedTreeMap<String, Object>>) pluginParams
          .get("Environments");
      System.out.println(envList + " is the list of array");
      for (LinkedTreeMap<String, Object> oneEnvMap : envList)
      {

        ArrayList<String> envList1 = (ArrayList) oneEnvMap.get("permissions");
        for (String envList2 : envList1)
        {
          // String permissions= envList1.get(0) ;
          String permissions = envList2;
          System.out.println(permissions + " is the permissions");
          userRoleAssign(pluginParams, permissions);
        }
      }
      map.put("Response ", userId + " created ");
      map.put("Environment ", environment);
      json.putAll(map);

      return json.toString();
    }
    catch (NamingException e)
    {
      System.out.println("user creation error");
      e.printStackTrace();
      map.put("Response ", "User Creation Error");
      map.put("Environment ", environment);
      json.putAll(map);
      return json.toString();
    }
    catch (ParseException e)
    {

      e.printStackTrace();
      System.out.println(dateInString + " cannot be parsed as a date. format: dd-M-yyyy hh:mm:ss");
      map.put("Response ", "Cannot be parsed as a date,Format required is dd-M-yyyy hh:mm:ss");
      map.put("Environment ", environment);
    }
    return "";
  }

  @SuppressWarnings("unused")
  private String getUserDN(final String username)
  {
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    // String userDN = new
    // StringBuffer().append("cn=").append(username).append(",CN=Users,DC=cgdevops,DC=aws,DC=capamlab,DC=com").toString();
    String userDN = new StringBuffer().append("cn=").append(username).append(",") + (searchBase);
    System.out.println(userDN);
    return userDN;
  }

  /**
   * Millis to filetime.
   *
   * @param millis the millis
   * @return the long
   */
  private static long millisToFiletime(long millis)
  {
    return (millis + FILETIME_EPOCH_DIFF) * FILETIME_ONE_MILLISECOND;
  }

  @SuppressWarnings("unchecked")
  public String updateUser(Map<String, Object> pluginParams, Map<String, String> envParams)
  {

    getLdapContext();
    String userId = (String) pluginParams.get("UserId");
    String lastName = (String) pluginParams.get("LastName");
    String environment = envParams.get("Environment");
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    ModificationItem[] mods = new ModificationItem[2];
    // mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
    // BasicAttribute("description", desc));
    mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("sn", lastName));

    mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userAccountControl", "546"));// 546-->DISABLE
                                                                                                                  // USER;544>NO
                                                                                                                  // PASSWORD;512-->ENABLE
    JSONObject jsonObj = new JSONObject();
    Map<String, String> hash_Map = new HashMap<>();
    try
    {
      ctx.modifyAttributes("CN=" + userId + "," + searchBase, mods);

      // System.out.println("descr changed");
      System.out.println("user updated");
      hash_Map.put("Response ", userId + "updated");
      hash_Map.put("Environment ", environment);
      jsonObj.putAll(hash_Map);
      return jsonObj.toString();
    }
    catch (NamingException e)
    {
      e.printStackTrace();
      System.out.println("change description failed" + e.getMessage());
      hash_Map.put("Response ", userId + "update failed");
      hash_Map.put("Environment ", environment);
      jsonObj.putAll(hash_Map);
      return jsonObj.toString();
    }
  }

  /**
   * User deletion. Deletes user
   * 
   * @param userName the user name
   * @return the string
   */

  @SuppressWarnings("unchecked")
  public String userDeletion(Map<String, Object> pluginParams, Map<String, String> envParams)
  {
    JSONObject json = new JSONObject();
    HashMap<String, String> map = new HashMap<String, String>();

    getLdapContext();
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    String userId = (String) pluginParams.get("UserId");
    String environment = envParams.get("Environment");
    try
    {

      ctx.unbind("cn=" + userId + "," + searchBase);
    }
    catch (NamingException e1)
    {
      e1.printStackTrace();
    }

    // Check that it is gone
    Object obj = null;
    try
    {
      obj = ctx.lookup("cn=" + userId + "," + searchBase);
    }
    catch (NameNotFoundException ne)
    {
      System.out.println("unbind successful");
      map.put("Response ", userId + "deleted ");
      map.put("Environment ", environment);
      json.putAll(map);
      return json.toString();
    }
    catch (NamingException e)
    {

      e.printStackTrace();
    }

    System.out.println("unbind failed; object still there: " + obj);
    map.put("Response ", "unbind failed; object still there: " + obj);
    map.put("Environment ", environment);
    json.putAll(map);
    return json.toString();
  }

  /**
   * User info.
   *
   * @param UserId the user id
   * @param Environment the environment
   * @return the string
   */

  @SuppressWarnings("unchecked")
  public String userInfo(Map<String, Object> pluginParams, Map<String, String> envParams)
  {
    JSONObject json = new JSONObject();
    ActiveDirectoryPlugins ldapExaminer = new ActiveDirectoryPlugins();
    String userId = (String) pluginParams.get("UserId");
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = printUserBasicAttributes(userId, ldapExaminer.getLdapContext());
    json.putAll(connectionConfiguration);
    return json.toString();
  }

  /**
   * Prints the user basic attributes.
   *
   * @param username the username
   * @param ctx the ctx
   * @return the map
   */
  private Map<String, String> printUserBasicAttributes(String username, LdapContext ctx)
  {
    Map<String, String> map = new HashMap<>();
    try
    {
      String distinguishedName;
      String firstName;
      String lastName;
      String canonicalName;
      String userAccountControl;
      String accountExpiryDate;
      String mail;
      SearchControls constraints = new SearchControls();
      constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
      // NOTE: The attributes mentioned in array below are the ones that will be
      // retrieved, you can add more.
      String[] attrIDs = { "distinguishedName", "sn", "givenname", "mail", "telephonenumber", "canonicalName",
          "userAccountControl", "accountExpires" };
      constraints.setReturningAttributes(attrIDs);

      // NOTE: replace DC=domain,DC=com below with your domain info. It is essentially
      // the Base Node for Search.
      Map<String, String> connectionConfiguration = null;
      connectionConfiguration = getConnectionConfig();
      String searchBase = connectionConfiguration.get("SEARCH_BASE");

      NamingEnumeration<?> answer = ctx.search(searchBase, "sAMAccountName=" + username, constraints);
      if (answer.hasMore())
      {
        Attributes attrs = ((SearchResult) answer.next()).getAttributes();
        distinguishedName = (String) attrs.get("distinguishedName").get();
        firstName = (String) attrs.get("givenname").get();
        lastName = (String) attrs.get("sn").get();
        canonicalName = (String) attrs.get("canonicalName").get();
        userAccountControl = (String) attrs.get("userAccountControl").get();
        accountExpiryDate = (String) attrs.get("accountExpires").get();
        mail = (String) attrs.get("mail").get();

        long nanoseconds = Long.parseLong(accountExpiryDate);
        long mills = (nanoseconds / 10000000);
        long unix = (((1970 - 1601) * 365) - 3 + Math.round((1970 - 1601) / 4)) * 86400L;
        long timeStamp = mills - unix;

        Date date = new Date(timeStamp * 1000L); // *1000 is to convert seconds to milliseconds

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z"); // the format of your date

        sdf.setTimeZone(TimeZone.getTimeZone("GMT")); // give a timezone reference for formating (see comment at
        // the bottom

        String formattedDate = sdf.format(date);
        System.out.println(distinguishedName + " is the distinguished search base");
        System.out.println(firstName + " is the first name");
        System.out.println(lastName + " is the last name");
        System.out.println(canonicalName + " is the cananical Domain name");
        System.out.println(userAccountControl + " is the account status");
        System.out.println(formattedDate + " is the Account Expiry date and time ");
        System.out.println(mail + " is the mail id");
        map.put("UserID ", username);
        map.put("FirstName ", firstName);
        map.put("LastName ", lastName);
        map.put("DomainCanonicalName ", canonicalName);
        map.put("ValidUpto ", formattedDate);
        map.put("StatusCode ", userAccountControl);
        map.put("Environment ", "Active Directory");
        map.put("EMail ", mail);
        return map;
      }
      else
      {
        System.out.println("user id not enabled");
        Attributes attrs = ((SearchResult) answer.next()).getAttributes();
        distinguishedName = (String) attrs.get("distinguishedName").get();
        System.out.println(distinguishedName + " is the distinguished search base");
        map.put("Response ", "UserID is not enabled/available");
        return map;
      }

    }
    catch (Exception ex)
    {
      ex.printStackTrace();

    }
    return map;

  }

  /**
   * User role assign.
   *
   * @param userName the user name
   * @param groupName the group name
   * @param arg2 the arg 2
   * @param arg3 the arg 3
   * @param arg4 the arg 4
   * @return the string
   * @throws NamingException
   */
  @SuppressWarnings("unchecked")
  public String userRoleAssign(Map<String, Object> pluginParams, String envParams) throws NamingException
  {
    getLdapContext();
    Map<String, String> connectionConfiguration = null;
    JSONObject jsonObj = new JSONObject();
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    String userId = (String) pluginParams.get("UserId");
    System.out.println("user id from creste user is " + userId);
    System.out.println(envParams + "is the env params");

    String groupName = envParams;
    // String filter = "(objectclass=*)";
    String filter = "(&(objectClass=User)(cn=*" + groupName + "*))";
    Attributes matchAttrs = new BasicAttributes(true); // ignore attribute name case
    matchAttrs.put(new BasicAttribute("cn", "Administrators"));
    matchAttrs.put(new BasicAttribute("mail"));
    // NamingEnumeration answer = ctx.search("ou=Groups", matchAttrs);
    SearchControls controls = new SearchControls();
    controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
    // controls.setSearchScope(SearchControls.ONELEVEL_SCOPE); // Use this for first
    // level DNs only

    NamingEnumeration<SearchResult> results = ctx.search("ou=Groups", matchAttrs);
    System.out.println(results + "is the search ");
    List<String> searchDNsList = new ArrayList<String>();//

    try
    {
      // Process attributes
      while (results.hasMore())
      {
        Attributes attrs = results.next().getAttributes();
        if (attrs != null)
        {
          Attribute distinguisedNames = attrs.get("distinguishedName");
          if (distinguisedNames != null)
          {
            NamingEnumeration enumeration = distinguisedNames.getAll();
            while (enumeration.hasMore())
            {
              String searchDN = (String) enumeration.next();
              searchDNsList.add(searchDN);
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    System.out.println(searchDNsList);
    ModificationItem[] mods = new ModificationItem[1];
    Map<String, String> roleAssignMap = new HashMap<>();
    // mods[0] = new
    // ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
    // BasicAttribute("description", "this is a demo user to be added to grp"));
    mods[0] = new ModificationItem(DirContext.ADD_ATTRIBUTE,
        new BasicAttribute("member", "CN=" + userId + "," + searchBase));

    try
    {
      ctx.modifyAttributes(groupName, mods);
      System.out.println("assigned to a grp");

      roleAssignMap.put("Response ", "Assigned to user groups");

      jsonObj.putAll(roleAssignMap);
      return jsonObj.toString();
    }
    catch (NamingException e)
    {

      System.out.println("role assigned failed" + e.getMessage());
      roleAssignMap.put("Response ", "Role Assigned Failed in AD");
      jsonObj.putAll(roleAssignMap);
      return jsonObj.toString();
    }
  }

  /**
   * Reset password. This plugin method is used for reset the password for created
   * user
   * 
   * @param username the username
   * @return the string
   * @throws NamingException
   * @throws IOException
   */

  public String resetPassword(Map<String, Object> pluginParams, Map<String, String> envParams)
  {

    getLdapContext();

    int UF_ACCOUNTDISABLE = 0x0002;
    int UF_PASSWD_NOTREQD = 0x0020;
    // int UF_PASSWD_CANT_CHANGE = 0x0040;
    int UF_NORMAL_ACCOUNT = 0x0200;
    // int UF_DONT_EXPIRE_PASSWD = 0x10000;
    int UF_PASSWORD_EXPIRED = 0x800000;

    // Note that you need to create the user object before you can
    // set the password. Therefore as the user is created with no
    // password, user AccountControl must be set to the following
    // otherwise the Win2K3 password filter will return error 53
    // unwilling to perform.
    Attributes attrs = new BasicAttributes(true);
    attrs.put("userAccountControl",
        Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWD_NOTREQD + UF_PASSWORD_EXPIRED + UF_ACCOUNTDISABLE));

    // now that we've created the user object, we can set the
    // password and change the userAccountControl
    // and because password can only be set using SSL/TLS
    // lets use StartTLS
    try
    {

      StartTlsResponse tls = (StartTlsResponse) ctx.extendedOperation(new StartTlsRequest());
      tls.negotiate();

      // set password is a ldap modfy operation
      // and we'll update the userAccountControl
      // enabling the acount and force the user to update ther password
      // the first time they login
      ModificationItem[] mods = new ModificationItem[2];

      // Replace the "unicdodePwd" attribute with a new value
      // Password must be both Unicode and a quoted string
      String newQuotedPassword = "\"Password2000\"";
      byte[] newUnicodePassword = newQuotedPassword.getBytes("UTF-16LE");

      mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
          new BasicAttribute("unicodePwd", newUnicodePassword));
      mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
          new BasicAttribute("userAccountControl", Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWORD_EXPIRED)));

      // Perform the update
      // HashMap<String, Object> map = new HashMap<String, Object>();
      String username = (String) pluginParams.get("UserId");
      ctx.modifyAttributes(username, mods);

      System.out.println("Set password & updated userccountControl");
    }
    catch (NamingException e)
    {
      e.printStackTrace();
      System.out.println("change description failed" + e.getMessage());
    }
    catch (UnsupportedEncodingException e)
    {

      e.printStackTrace();
    }
    catch (IOException e)
    {

      e.printStackTrace();
    }
    return null;
  }

  /**
   * Gets the ldap context.
   *
   * @return the ldap context
   */
  public LdapContext getLdapContext()
  {

    try
    {
      Map<String, String> connectionConfiguration = null;
      connectionConfiguration = getConnectionConfig();
      // Reading the configuration details for logging into Active directory system
      // from the
      // connectionConfiguration.
      String contextFactory = connectionConfiguration.get("INITIALCONTEXTFACTORY");
      String password = connectionConfiguration.get("PASSWORD");
      String user = connectionConfiguration.get("USER");
      String sysnr = connectionConfiguration.get("SECURITY_AUTHENTICATION");
      String url = connectionConfiguration.get("PROVIDER_URL");
      logger.info(contextFactory);
      logger.info("ASHost" + contextFactory);

      logger.info(user);
      logger.info("USER" + user);
      logger.info(sysnr);
      logger.info("SYSNR" + sysnr);
      logger.info(url);
      logger.info("PROVIDER_URL" + url);
      logger.info("It is working normally");
      Hashtable<String, String> env = new Hashtable<String, String>();
      env.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
      env.put(Context.SECURITY_AUTHENTICATION, sysnr);
      env.put(Context.SECURITY_PRINCIPAL, user);// input user & password for access to ldap
      env.put(Context.SECURITY_CREDENTIALS, password);
      env.put(Context.PROVIDER_URL, url);
      System.out.println("Attempting to Connect...");

      ctx = new InitialLdapContext(env, null);
      System.out.println("Connection Successful.");
    }
    catch (NamingException nex)
    {
      System.out.println("LDAP Connection: FAILED");
      nex.printStackTrace();
    }
    return ctx;
  }

  /**
   * This method is to take the configuration details of Active Directory from a
   * configuration file. configuration parameters are: USER - which resembles the
   * userName, PASSWORD - which resembles the password,
   * 
   *
   * @return the connection config
   */
  private Map<String, String> getConnectionConfig()
  {
    try
    {
      Properties connectionProperty = new Properties();
      String configFile = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\ActiveDirectory.properties";
      FileReader fReader = null;
      fReader = new FileReader(configFile);
      try
      {
        connectionProperty.load(fReader);
      }
      catch (IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
      hashMap.put("INITIALCONTEXTFACTORY", connectionProperty.getProperty("INITIAL_CONTEXT_FACTORY"));
      hashMap.put("USER", connectionProperty.getProperty("USER"));
      hashMap.put("PASSWORD", connectionProperty.getProperty("PASSWORD"));
      hashMap.put("SECURITY_AUTHENTICATION", connectionProperty.getProperty("SECURITY_AUTHENTICATION"));
      hashMap.put("PROVIDER_URL", connectionProperty.getProperty("PROVIDER_URL"));
      hashMap.put("EMAIL", connectionProperty.getProperty("EMAIL"));
      hashMap.put("PASSWORDEMAIL", connectionProperty.getProperty("PASSWORDEMAIL"));
      hashMap.put("SEARCH_BASE", connectionProperty.getProperty("SEARCH_BASE"));
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    return hashMap;
  }

  /**
   * Geek password. This our Password generating method We have use static here,
   * so that we need not make any object for it
   * 
   * @return the string
   */
  static String geek_Password()
  {
    int MAX_LENGTH = 16;
    String DIGITS = "23456789";
    String LOCASE_CHARACTERS = "abcdefghjkmnpqrstuvwxyz";
    String UPCASE_CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZ";
    String SYMBOLS = "@#$%=:?";
    String ALL = DIGITS + LOCASE_CHARACTERS + UPCASE_CHARACTERS + SYMBOLS;
    char[] upcaseArray = UPCASE_CHARACTERS.toCharArray();
    char[] locaseArray = LOCASE_CHARACTERS.toCharArray();
    char[] digitsArray = DIGITS.toCharArray();
    char[] symbolsArray = SYMBOLS.toCharArray();
    char[] allArray = ALL.toCharArray();
    Random r = new Random();

    StringBuilder sb = new StringBuilder();

    // get at least one lowercase letter
    sb.append(locaseArray[r.nextInt(locaseArray.length)]);

    // get at least one uppercase letter
    sb.append(upcaseArray[r.nextInt(upcaseArray.length)]);

    // get at least one digit
    sb.append(digitsArray[r.nextInt(digitsArray.length)]);

    // get at least one symbol
    sb.append(symbolsArray[r.nextInt(symbolsArray.length)]);

    // fill in remaining with random letters
    for (int i = 0; i < MAX_LENGTH - 4; i++)
    {
      sb.append(allArray[r.nextInt(allArray.length)]);
    }

    return sb.toString();
  }
  
  /**
   * The main method.
   *
   * @param args the arguments
   * @throws NamingException the naming exception
   */
  public static void main(String[] args)
  {
    System.out.println("hi");

  }

  @Override
  public String createUser(String environment, String userName, String name, String eMail,
      Map<String, String> pluginParams)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String resetPassword(String environment, String userId)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String updateUser(String environment, String userName, String desc, String lastName)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String userInfo(String userName, String environment)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String userDeletion(String environment, String userId)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String userRoleAssign(String environment, String userId, String roleAssigned, Map<String, String> pluginParams)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public ResultsBlock createUser(Parameters parameters)
  {
    ResultsBlock result; 
    for (String client: parameters.getClients()) {
      for (String landscape: parameters.getEnvironmentsOfClientType(client, this.environmentTag)) {
        ClientContext clientContext = getClientContext(client);
        Attributes container = new BasicAttributes();
        container.put("objectClass","User");
        container.put("cn", parameters.getField("id"));
        container.put("sAMAccountName", parameters.getField("id"));
        container.put("mail", parameters.getField("email"));
        container.put("givenName", parameters.getField("first_name"));
        container.put("uid", parameters.getField("id"));
        container.put("sn", parameters.getField("last_name"));
        container.put("displayName", parameters.getField("first_name") + " " + parameters.getField("last_name"));
        container.put("description", parameters.getField("department"));
        container.put("userPrincipalName", parameters.getField("id"));
        container.put("accountExpires", parameters.getField("end_date"));
        // container.put("userpassword", );
        LdapContext context = clientContext.getEnvironmentConfiguration(landscape).getLdapContext();
        context.createSubcontext(getUserDN(parameters.getField("id")), container);
        context.close();
      }
    }
    return result;
  }

  private ClientContext getClientContext(String client)
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public ResultsBlock validateParameters(Parameters parameters)
  {
    // TODO Auto-generated method stub
    return null;
  }
}