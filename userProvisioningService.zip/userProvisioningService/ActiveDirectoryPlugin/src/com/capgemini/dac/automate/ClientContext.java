package com.capgemini.dac.automate;

import java.util.HashMap;

public class ClientContext
{
  HashMap<String, ClientEnvironmentConfiguration> ldapConnections;
  
  public ClientContext() {
    
  }
  
  public ClientContext(String fileName) {
    
  }
  
  public ClientContext(String clientName, String fileName) {
    
  }
  
  public void loadConfiguration(String clientName, String fileName) {
    
  }
  
  public ClientEnvironmentConfiguration getEnvironmentConfiguration(String environment) {
    return null;
  }
  
  public void setEnvironmentConfiguration(String name, ClientEnvironmentConfiguration environment) {
    
  }
  public boolean hasEnvironment(String environment) {
    return false;
  }
}