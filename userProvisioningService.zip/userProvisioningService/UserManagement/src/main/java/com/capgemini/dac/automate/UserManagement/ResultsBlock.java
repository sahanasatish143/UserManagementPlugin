package com.capgemini.dac.automate.UserManagement;

public class ResultsBlock
{

  public boolean hasErrors()
  {
    // TODO Auto-generated method stub
    return false;
  }

  public ResultsBlock mergeResults(ResultsBlock createUser)
  {
    // TODO Auto-generated method stub
    return null;
  }

  public String toJSONResponse()
  {
    // TODO Auto-generated method stub
    return null;
  }

  public void setErrors(boolean b)
  {
    // TODO Auto-generated method stub
    
  }

  public void addMessage(String string, String string2)
  {
    // TODO Auto-generated method stub
    
  }

  public void setWarning(boolean b)
  {
    // TODO Auto-generated method stub
    
  }

}
