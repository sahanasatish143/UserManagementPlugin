/*
 * Copyright (c) 2019-2020, Capgemini and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Please contact DAC Team in Capgemini if you need additional information or
 * have any questions.
 */

package com.capgemini.dac.automate.UserManagement;

import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.capgemini.dac.automate.UserManagementPlugin;

/**
 * Represents a collection of Tasks for an Automic JobP object.
 * 
 * @author Shannon B. Miles &lt;shannon.miles@capgemini.com&gt;
 * @version 1.0
 * @since 1.8
 */
public class CentralServices
{
  
  private Logger logger;
  private Properties configuration;
  
  /**
   * Constructor to build a default CentralServices object.
   */
  public CentralServices(MainResource mainResource)
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * This method allows a component to retrieve the location of its 
   * configuration file from the host application. This depends on the 
   * plugin's configuration being specified in the main configuration file. 
   *
   * @param componentName the name of the component requesting its configuration file
   * @returns fully qualified name of a component configuration file
   */
  public String getConfigFilename(String componentName)
  {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * Provides access to the applications central logger.
   *
   * @returns the central logger instance
   */
  public Logger getLogger()
  {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * This method allows UserManagementPlugin to register its active instance 
   * with the central environment for usage. 
   *
   * @param pluginName the name class name of the plugin
   * @param pluginIdentifyer the JSON tag used to denote the plugin environment
   * @param version the version of the plugin
   * @param pluginObject a reference to the loaded instance of the plugin
   */
  public void registerUserManagementPlugin(String pluginName, String pluginIdentifyer, String version,
      UserManagementPlugin pluginObject)
  {
    // TODO Auto-generated method stub
  }

  /**
   * This method initialize a single mail as a response
   * to a request that can be coordinated by multiple components. 
   *
   * @param requestID the id of the request that is being replied to
   * @param eMail the recipient email address
   * @param subject the subject of the mail
   * @param salutation the salutation of the mail
   * @param Signature the signature of the mail
   */
  public void initializeResponseMail(String requestID, String eMail, String subject, String salutation, String Signature) {
    
  }
  
  /**
   * This method allows multiple components to add to a single mail as a response
   * to a request.  
   *
   * @param requestID the id of the request that is being replied to
   * @param client the client who's system this portion of the request was performed on
   * @param environment the environment that this portion of the request was performed on
   * @param body the body section to add
l
   */
  public void addToResponseMail(String requestID, String client, String environment, String body) {
    
  }
  
  /**
   * This method performs the final assembly of the cross component mail and sends 
   * it. 
   *
   * @param requestID the id of the request that is being replied to
   */
  public void finalizeAndSendResponseMail(String requestID) {
    
  }
  
  /**
   * Send email.
   *
   * @param eMail the e mail
   * @param sub2 the sub 2
   * @param msg2 the msg 2
   */
  public void sendEmail(String eMail, String sub, String msg)
  {
    final String from = configuration.getProperty("EMAIL");// testmailid
    final String password = configuration.getProperty("PASSWORDEMAIL"); // testpwds
    logger.info(from + "email");
    Properties props = new Properties();
    props.put("mail.smtp.auth", "true");
    props.put("mail.smtp.starttls.enable", "true");
    props.put("mail.smtp.host", "outlook.office365.com");
    props.put("mail.smtp.port", "587");
    Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator()
    {
      protected PasswordAuthentication getPasswordAuthentication()
      {
        return new PasswordAuthentication(from, password);
      }
    });

    // Compose the message
    try
    {
      MimeMessage message = new MimeMessage(session);
      message.setFrom(new InternetAddress(from));
      message.addRecipient(Message.RecipientType.TO, new InternetAddress(eMail));

      message.setSubject(sub);
      message.setText(msg);
      // send the message
      Transport.send(message);
      logger.info("message sent successfully...");
    }
    catch (MessagingException e)
    {
      e.printStackTrace();
    }
  }

  /**
   * This method allows the global logger instance to be registered with the 
   * central environment for usage. 
   *
   * @param logger a reference to the logger instance
   */
  public void registerLogger(Logger logger)
  {
    // TODO Auto-generated method stub
    
  }

  /**
   * This method allows the PluginManager to be registered  
   * with the central environment for usage. 
   *
   * @param pluginManager the name class name of the plugin
   */
  public void registerPluginManager(PluginManager pluginManager)
  {
    // TODO Auto-generated method stub
    
  }
}