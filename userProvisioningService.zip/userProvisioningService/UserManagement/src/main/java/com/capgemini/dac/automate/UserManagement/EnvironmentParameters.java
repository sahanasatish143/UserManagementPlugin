package com.capgemini.dac.automate.UserManagement;

import java.util.ArrayList;
import java.util.Iterator;

public class EnvironmentParameters
{
  String environment;
  String client;
  String landscape;
  ArrayList<String> permissions;
  
  public EnvironmentParameters() {
    permissions = new ArrayList<String>();
  }
  
  public EnvironmentParameters (String environment, String client, String landscape) {
    permissions = new ArrayList<String>();
    this.setClient(client);
    this.setEnvironment(environment);
    this.setLandscape(landscape);
  }
  
  public String getClient() {
    return client;
  }
  
  public void setClient(String client) {
    this.client = client;
  }
  
  public String getEnvironment() {
    return environment;
  }

  public void setEnvironment(String environment) {
    this.environment = environment;
  }
  
  public String getLandscape() {
    return landscape;
  }

  public void setLandscape(String landscape) {
    this.landscape = landscape;
  }
  
  public Iterator<String> iterator() {
    return permissions.iterator();
  }
  
  public void add(String permission) {
    permissions.add(permission);
  }
}