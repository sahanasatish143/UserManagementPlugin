package com.capgemini.dac.automate.UserManagement.Validation.Service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class ParameterValues {
	
	private  Map<ParameterEnum, String> parameterValuesMap = new HashMap<ParameterEnum, String>();
	
	
	public String get(ParameterEnum key)
	{
		return parameterValuesMap.get(key);
	}
	
	// Helper methods to make validation easy
	//Rather than duplicating code in all the places where we'll validate this encapsulates it and avoids repetition (DRY)
	public String checkRequiredFields(HashSet<ParameterEnum> required)
	{
	   String ret=null;
	   if (! parameterValuesMap.keySet().containsAll(required) ) 
	   {
		    // Remove the fields we have from the required so we return all the missing fields.
		    // It's more user friendly to return all the missing fields if possible so they don't have
		   // to fix one missing field, test, then fix the next missing field.
		   required.removeAll(parameterValuesMap.keySet());
		   ret = required.toString();
	   }
	   return ret;
	}
	
	 // Makes displaying the parameters (debug) easier
	public String toString()
	{
		return parameterValuesMap.toString();
	}

} //ParameterValues class
