package com.capgemini.dac.automate.UserManagement.Validation.Fields;

public class ValidationFields {
	

	private String name;
	private String fieldType;
	private String defaultValue;
	private String format;
	private String dateformat;
	private Boolean required;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFieldType () {
		return fieldType ;
	}
	public void setFieldType(String fieldType ) {
		this.fieldType  = fieldType ;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getdateFormat() {
		return dateformat;
	}
	public void setdateFormat(String dateformat) {
		this.dateformat = dateformat;
	}
	public Boolean getRequired() {
		return required;
	}
	public void setRequired(Boolean required) {
		this.required = required;
	
	}
	
}
