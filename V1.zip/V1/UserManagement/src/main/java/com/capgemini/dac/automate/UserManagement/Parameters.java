package com.capgemini.dac.automate.UserManagement;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import com.capgemini.dac.automate.UserManagement.Validation.Fields.ValidationFields;

public class Parameters
{
  Properties properties = new Properties();
  ArrayList<EnvironmentParameters> environments = new ArrayList<EnvironmentParameters>();
  ArrayList<String> roles = new ArrayList<String>();
  
//  public Parameters() {
//    this.addField("Version", "1.0.0");
//  }
  
//  public Parameters(String version) {
//    this.addField("Version", version);
//  }
  
  public Parameters initializeFromJSON(String json) {
    try
    {
      JSONObject jsonObject = new JSONObject(json);
      Iterator<String> it = jsonObject.keys();
      while (it.hasNext())
      {
        String key = it.next();
        if (key.equals("environments"))
          this.paserEnvironment(jsonObject.get(key).toString());
        else if (key.equals("roles"))
          this.parseRoles(jsonObject.get(key).toString());
        else
          this.properties.put(key, jsonObject.get(key));
      }
    }
    catch (Exception ex)
    {
      System.out.println(ex);
    }
    return this;
  }
  
  private void parseRoles(String json)
  {
    try
    {
      JSONArray roles = new JSONArray(json);
      Iterator<Object> vit = roles.iterator();
      while (vit.hasNext()) {
        this.roles.add(vit.next().toString());
      }
    }
    catch (Exception ex)
    {
      System.out.println(ex);
    }
  }

  private void paserEnvironment(String json)
  {
    try
    {
      JSONObject jsonObject = new JSONObject(json);
      Iterator<String> it = jsonObject.keys();
      while (it.hasNext())
      {
        String client = it.next();
        JSONObject environments = (JSONObject) jsonObject.get(client);
        Iterator<String> eit = environments.keys();
        while (eit.hasNext()) {
          String environment = eit.next();
          JSONObject value = (JSONObject) environments.get(environment);
          Iterator<String> lit = value.keys();
          while (lit.hasNext()) {
            String landscape = lit.next();
            EnvironmentParameters enviro = new EnvironmentParameters(environment, client, landscape);
            this.environments.add(enviro);
            JSONArray lvalue = (JSONArray) value.get(landscape);
            Iterator<Object> vit = lvalue.iterator();
            while (vit.hasNext()) {
              enviro.add(vit.next().toString());
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      System.out.println(ex);
    }
  }

//  public Parameters addField(ValidationFields name, ArrayList<ValidationFields> arrayList) {
//    properties.setProperty(name.toString(), arrayList);
//    return this;
//  }
//  
  public boolean hasField(String key) {
    return properties.containsKey(key);
  }
  
  public String getField(ValidationFields name)
  {
    return properties.getProperty(name.toString());
  }
  
  public ArrayList<String> getClients() {
    ArrayList<String> result = new ArrayList<String>();
    for (EnvironmentParameters temp : environments) {
      if(!result.contains(temp.getClient()))
        result.add(temp.getClient());
    }
    return result;
  }
  
  public ArrayList<String> getEnvironmentNames() {
    ArrayList<String> result = new ArrayList<String>();
    for (EnvironmentParameters temp : environments) {
      if(!result.contains(temp.getEnvironment()))
        result.add(temp.getEnvironment());
    }
    return result;
  }
  
  public ArrayList<String> getLandscapes() {
    ArrayList<String> result = new ArrayList<String>();
    for (EnvironmentParameters temp : environments) {
      if(!result.contains(temp.getLandscape()))
        result.add(temp.getLandscape());
    }
    return result;
  }
  
  public ArrayList<String> getLandscapesForEnvironment(String environment) {
    ArrayList<String> result = new ArrayList<String>();
    for (EnvironmentParameters temp : environments) {
      if(temp.getEnvironment().equals(environment) && !result.contains(temp.getLandscape()))
        result.add(temp.getLandscape());
    }
    return result;
  }
  
  public ArrayList<EnvironmentParameters> getEnvironmentsOfType(String type) {
    ArrayList<EnvironmentParameters> result = new ArrayList<EnvironmentParameters>();
    for (EnvironmentParameters temp : environments) {
      if(temp.getEnvironment().equals(type))
        result.add(temp);
    }
    return result;
  }
  
  public ArrayList<EnvironmentParameters> getEnvironmentsOfClient(String client) {
    ArrayList<EnvironmentParameters> result = new ArrayList<EnvironmentParameters>();
    for (EnvironmentParameters temp : environments) {
      if(temp.getClient().equals(client))
        result.add(temp);
    }
    return result;
  }
  
  public Enumeration<String> fieldNames() {
    return (Enumeration<String>) properties.propertyNames();
  }

  public ArrayList<String> getEnvironmentsOfClientType(String client, String environment)
  {
    // TODO Auto-generated method stub
    return null;
  }
}