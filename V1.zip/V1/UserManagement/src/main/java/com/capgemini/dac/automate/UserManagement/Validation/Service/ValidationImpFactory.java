package com.capgemini.dac.automate.UserManagement.Validation.Service;

import java.util.Map;

import com.capgemini.dac.automate.UserManagement.Exception.InvalidPluginArguments;

/**
 * A factory for creating ValidationImp objects.
 */
public interface ValidationImpFactory {
	
	/**
	 * Validate required field.
	 *
	 * @param myMap the my map
	 * @param oneEnvMap the one env map
	 * @return the string
	 * @throws InvalidPluginArguments the invalid plugin arguments
	 */
	public String validateRequiredField(Map<String, Object> myMap,Map<String, String> oneEnvMap) throws InvalidPluginArguments;

	/**
	 * Validate format.
	 *
	 * @param myMap the my map
	 * @param oneEnvMap the one env map
	 * @return the string
	 * @throws InvalidPluginArguments the invalid plugin arguments
	 */
	public boolean  validateFormat(Map<String, Object> myMap,Map<String, String> oneEnvMap)throws InvalidPluginArguments;
	
}
