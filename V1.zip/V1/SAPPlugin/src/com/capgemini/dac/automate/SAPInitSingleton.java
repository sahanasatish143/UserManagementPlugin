/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate;

/**
 * The Class MySingleton. singleton for a class that stores the map for the
 * plugins. It will return the map values in the response. Each time it's called
 * the map returns will all the previous values too.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 * @author Abhishek Tenneti; abhishek.tenneti@capgemini.com
 */
public class SAPInitSingleton
{

  /** The my singleton instance. */
  private static SAPInitSingleton mySingleton_instance = null;


  /**
   * Default constructor
   * Instantiates a new my singleton.
   */

  private SAPInitSingleton()
  {

  }

  /**
   * static method to create instance of Singleton class
   * 
   *
   * @return single instance of MySingleton
   */
  public static SAPInitSingleton getInstance(String destName)
  {
    
    if (mySingleton_instance == null)
    {
      MySapDestDataProvider myProvider = new MySapDestDataProvider();
      
      //register the provider with the JCo environment;
      //catch IllegalStateException if an instance is already registered
        com.sap.conn.jco.ext.Environment.registerDestinationDataProvider(myProvider);
        myProvider.addDestination(destName, SAPPlugins.getDestinationProperties());
       
        mySingleton_instance = new SAPInitSingleton();
    }
    return mySingleton_instance;
  }

 
}
