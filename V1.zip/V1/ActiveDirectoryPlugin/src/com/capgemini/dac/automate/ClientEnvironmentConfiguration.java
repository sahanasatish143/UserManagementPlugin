package com.capgemini.dac.automate;

import java.util.ArrayList;
import java.util.Iterator;

import javax.naming.ldap.LdapContext;

public class ClientEnvironmentConfiguration
{
  String name = "";
  String initialContectFactory = "";
  String user = "";
  String password;
  String securityAuthentication = "";
  String providerURL = "";
  String email = "";
  String emailPassword = "";
  ArrayList<String> searchBases = new ArrayList<String>();
  
  public ClientEnvironmentConfiguration() {
    
  }
  
  public void addSearchBase(String searchBase) {
    searchBases.add(searchBase);
  }
  
  public Iterator<String> getSearchBaseIterator() {
    return searchBases.iterator();
  }
  
  public LdapContext getLdapContext() {
    return null;
  }

  /**
   * @return the name
   */
  public String getName()
  {
    return this.name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name)
  {
    this.name = name;
  }

  /**
   * @return the initialContectFactory
   */
  public String getInitialContectFactory()
  {
    return this.initialContectFactory;
  }

  /**
   * @param initialContectFactory the initialContectFactory to set
   */
  public void setInitialContectFactory(String initialContectFactory)
  {
    this.initialContectFactory = initialContectFactory;
  }

  /**
   * @return the user
   */
  public String getUser()
  {
    return this.user;
  }

  /**
   * @param user the user to set
   */
  public void setUser(String user)
  {
    this.user = user;
  }

  /**
   * @return the password
   */
  public String getPassword()
  {
    return this.password;
  }

  /**
   * @param password the password to set
   */
  public void setPassword(String password)
  {
    this.password = password;
  }

  /**
   * @return the securityAuthentication
   */
  public String getSecurityAuthentication()
  {
    return this.securityAuthentication;
  }

  /**
   * @param securityAuthentication the securityAuthentication to set
   */
  public void setSecurityAuthentication(String securityAuthentication)
  {
    this.securityAuthentication = securityAuthentication;
  }

  /**
   * @return the providerURL
   */
  public String getProviderURL()
  {
    return this.providerURL;
  }

  /**
   * @param providerURL the providerURL to set
   */
  public void setProviderURL(String providerURL)
  {
    this.providerURL = providerURL;
  }

  /**
   * @return the email
   */
  public String getEmail()
  {
    return this.email;
  }

  /**
   * @param email the email to set
   */
  public void setEmail(String email)
  {
    this.email = email;
  }

  /**
   * @return the emailPassword
   */
  public String getEmailPassword()
  {
    return this.emailPassword;
  }

  /**
   * @param emailPassword the emailPassword to set
   */
  public void setEmailPassword(String emailPassword)
  {
    this.emailPassword = emailPassword;
  }
}