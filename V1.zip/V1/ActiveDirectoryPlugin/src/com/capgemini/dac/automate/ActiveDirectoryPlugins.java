/*
* Copyright (c) 2019, Capgemini and/or its affiliates. All rights reserved.
* DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
*
* This code is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE.
*
* Please contact DAC Team in Capgemini if you need additional information or
* have any questions.
*/

package com.capgemini.dac.automate;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.StartTlsRequest;
import javax.naming.ldap.StartTlsResponse;

import org.json.simple.JSONObject;

import com.capgemini.dac.automate.UserManagement.CentralServices;
import com.capgemini.dac.automate.UserManagement.Parameters;
import com.capgemini.dac.automate.UserManagement.ResultsBlock;

/**
 * This class represents the UserProvisioningService of ActiveDirectoryPlugins.
 * 
 * @author Sahana S; sahana.b.s@capgemini.com
 */
public abstract class ActiveDirectoryPlugins implements UserManagementPlugin
{
  enum ACTION {
    CREATE,
    UPDATE,
    MODIFY
  };

  /** The Constant logger. */
  private Logger logger;

  /** The hash map. */
  static Map<String, String> hashMap = new HashMap<>();
  static HashMap<String, String> hashMapValid = new HashMap<>();

  /** The hash map value. */
  static Map<String, String> hashMapValue = new HashMap<>();

  /** The ldap context. */
  DirContext ldapContext;

  /** The jsonrsponse from AD. */
  static String jsonresponse;

  /** The ctx. */
  LdapContext ctx = null;
  /** The sub. */
  static String sub;

  /** The message string. */
  static String msg;

  /** The to. */
  static String to;

  /** The Constant FILETIME_EPOCH_DIFF. */
  final static long FILETIME_EPOCH_DIFF = 11644473600000L;

  /**
   * One millisecond expressed in units of 100s of nanoseconds.
   */
  final static long FILETIME_ONE_MILLISECOND = 10 * 1000;
  
  //HashMap<String, ClientContext> clients = new HashMap<String, ClientContext>(); //collection of clients and there configuration
  private String configurationFile = ""; // file where current configuration stuff was loaded from
  private CentralServices centralService = null; // for services needed by all plugins like mail or logging
  private String environmentTag = "active_directory";
  
  public ActiveDirectoryPlugins() {
    
  }
  
  public ActiveDirectoryPlugins(CentralServices centralServices) {
    this.centralService = centralServices;
    this.configurationFile = this.centralService.getConfigFilename("ActiveDirectory");
    this.logger = this.centralService.getLogger();
    centralService.registerUserManagementPlugin("ActiveDirectoryPlugin", "active_directory", "1.0.0", this);
    this.loadConfiguration();
  }
  
  public ActiveDirectoryPlugins(Object centralServices, String filename) {
    
  }
  
  public void loadConfiguration() {
    
  }
  
  public void loadConfiguration(String filename) {
    this.configurationFile = filename;
    this.loadConfiguration();
  }
  
  /**
   * This method is an unimplemented plugin method where we will be having in the
   * AD interface level.
   *
   * @return the user
   */
  public String getUser()
  {
    return this.environmentTag;
  }

  /**
   * This plugin method is used for create the AD User It first logging into the
   * AD system through adtest user and then creates a new user
   *
   * @param username the username
   * @param givenName the First name
   * @param lastName the last name
   * @param eMail the e mail
   * @param canonicalName is the domain canonical name
   * @return the string
   */
  
  

  @SuppressWarnings("unused")
  private String getUserDN(final String username)
  {
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    // String userDN = new
    // StringBuffer().append("cn=").append(username).append(",CN=Users,DC=cgdevops,DC=aws,DC=capamlab,DC=com").toString();
    String userDN = new StringBuffer().append("cn=").append(username).append(",") + (searchBase);
    System.out.println(userDN);
    return userDN;
  }

  @SuppressWarnings("unchecked")
  public String updateUser(Map<String, Object> pluginParams, Map<String, String> envParams)
  {

    getLdapContext();
    String userId = (String) pluginParams.get("UserId");
    String lastName = (String) pluginParams.get("LastName");
    String environment = envParams.get("Environment");
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    ModificationItem[] mods = new ModificationItem[2];
    // mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
    // BasicAttribute("description", desc));
    mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("sn", lastName));

    mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userAccountControl", "546"));// 546-->DISABLE
                                                                                                                  // USER;544>NO
                                                                                                                  // PASSWORD;512-->ENABLE
    JSONObject jsonObj = new JSONObject();
    Map<String, String> hash_Map = new HashMap<>();
    try
    {
      ctx.modifyAttributes("CN=" + userId + "," + searchBase, mods);

      // System.out.println("descr changed");
      System.out.println("user updated");
      hash_Map.put("Response ", userId + "updated");
      hash_Map.put("Environment ", environment);
      jsonObj.putAll(hash_Map);
      return jsonObj.toString();
    }
    catch (NamingException e)
    {
      e.printStackTrace();
      System.out.println("change description failed" + e.getMessage());
      hash_Map.put("Response ", userId + "update failed");
      hash_Map.put("Environment ", environment);
      jsonObj.putAll(hash_Map);
      return jsonObj.toString();
    }
  }

  /**
   * User deletion. Deletes user
   * 
   * @param userName the user name
   * @return the string
   */

  @SuppressWarnings("unchecked")
  public String userDeletion(Map<String, Object> pluginParams, Map<String, String> envParams)
  {
    JSONObject json = new JSONObject();
    HashMap<String, String> map = new HashMap<String, String>();

    getLdapContext();
    Map<String, String> connectionConfiguration = null;
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    String userId = (String) pluginParams.get("UserId");
    String environment = envParams.get("Environment");
    try
    {

      ctx.unbind("cn=" + userId + "," + searchBase);
    }
    catch (NamingException e1)
    {
      e1.printStackTrace();
    }

    // Check that it is gone
    Object obj = null;
    try
    {
      obj = ctx.lookup("cn=" + userId + "," + searchBase);
    }
    catch (NameNotFoundException ne)
    {
      System.out.println("unbind successful");
      map.put("Response ", userId + "deleted ");
      map.put("Environment ", environment);
      json.putAll(map);
      return json.toString();
    }
    catch (NamingException e)
    {

      e.printStackTrace();
    }

    System.out.println("unbind failed; object still there: " + obj);
    map.put("Response ", "unbind failed; object still there: " + obj);
    map.put("Environment ", environment);
    json.putAll(map);
    return json.toString();
  }

  /**
   * User info.
   *
   * @param UserId the user id
   * @param Environment the environment
   * @return the string
   */

  /**
   * User role assign.
   *
   * @param userName the user name
   * @param groupName the group name
   * @param arg2 the arg 2
   * @param arg3 the arg 3
   * @param arg4 the arg 4
   * @return the string
   * @throws NamingException
   */
  @SuppressWarnings("unchecked")
  public String userRoleAssign(Map<String, Object> pluginParams, String envParams) throws NamingException
  {
    getLdapContext();
    Map<String, String> connectionConfiguration = null;
    JSONObject jsonObj = new JSONObject();
    connectionConfiguration = getConnectionConfig();
    String searchBase = connectionConfiguration.get("SEARCH_BASE");
    String userId = (String) pluginParams.get("UserId");
    System.out.println("user id from creste user is " + userId);
    System.out.println(envParams + "is the env params");

    String groupName = envParams;
    Attributes matchAttrs = new BasicAttributes(true); // ignore attribute name case
    matchAttrs.put(new BasicAttribute("cn", "Administrators"));
    matchAttrs.put(new BasicAttribute("mail"));
    // NamingEnumeration answer = ctx.search("ou=Groups", matchAttrs);
    SearchControls controls = new SearchControls();
    controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
    // controls.setSearchScope(SearchControls.ONELEVEL_SCOPE); // Use this for first
    // level DNs only

    NamingEnumeration<SearchResult> results = ctx.search("ou=Groups", matchAttrs);
    System.out.println(results + "is the search ");
    List<String> searchDNsList = new ArrayList<String>();//

    try
    {
      // Process attributes
      while (results.hasMore())
      {
        Attributes attrs = results.next().getAttributes();
        if (attrs != null)
        {
          Attribute distinguisedNames = attrs.get("distinguishedName");
          if (distinguisedNames != null)
          {
            NamingEnumeration enumeration = distinguisedNames.getAll();
            while (enumeration.hasMore())
            {
              String searchDN = (String) enumeration.next();
              searchDNsList.add(searchDN);
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    System.out.println(searchDNsList);
    ModificationItem[] mods = new ModificationItem[1];
    Map<String, String> roleAssignMap = new HashMap<>();
    // mods[0] = new
    // ModificationItem(DirContext.REPLACE_ATTRIBUTE, new
    // BasicAttribute("description", "this is a demo user to be added to grp"));
    mods[0] = new ModificationItem(DirContext.ADD_ATTRIBUTE,
        new BasicAttribute("member", "CN=" + userId + "," + searchBase));

    try
    {
      ctx.modifyAttributes(groupName, mods);
      System.out.println("assigned to a grp");

      roleAssignMap.put("Response ", "Assigned to user groups");

      jsonObj.putAll(roleAssignMap);
      return jsonObj.toString();
    }
    catch (NamingException e)
    {

      System.out.println("role assigned failed" + e.getMessage());
      roleAssignMap.put("Response ", "Role Assigned Failed in AD");
      jsonObj.putAll(roleAssignMap);
      return jsonObj.toString();
    }
  }

  /**
   * Reset password. This plugin method is used for reset the password for created
   * user
   * 
   * @param username the username
   * @return the string
   * @throws NamingException
   * @throws IOException
   */

  public String resetPassword(Map<String, Object> pluginParams, Map<String, String> envParams)
  {

    getLdapContext();

    int UF_ACCOUNTDISABLE = 0x0002;
    int UF_PASSWD_NOTREQD = 0x0020;
    // int UF_PASSWD_CANT_CHANGE = 0x0040;
    int UF_NORMAL_ACCOUNT = 0x0200;
    // int UF_DONT_EXPIRE_PASSWD = 0x10000;
    int UF_PASSWORD_EXPIRED = 0x800000;

    // Note that you need to create the user object before you can
    // set the password. Therefore as the user is created with no
    // password, user AccountControl must be set to the following
    // otherwise the Win2K3 password filter will return error 53
    // unwilling to perform.
    Attributes attrs = new BasicAttributes(true);
    attrs.put("userAccountControl",
        Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWD_NOTREQD + UF_PASSWORD_EXPIRED + UF_ACCOUNTDISABLE));

    // now that we've created the user object, we can set the
    // password and change the userAccountControl
    // and because password can only be set using SSL/TLS
    // lets use StartTLS
    try
    {

      StartTlsResponse tls = (StartTlsResponse) ctx.extendedOperation(new StartTlsRequest());
      tls.negotiate();

      // set password is a ldap modfy operation
      // and we'll update the userAccountControl
      // enabling the acount and force the user to update ther password
      // the first time they login
      ModificationItem[] mods = new ModificationItem[2];

      // Replace the "unicdodePwd" attribute with a new value
      // Password must be both Unicode and a quoted string
      String newQuotedPassword = "\"Password2000\"";
      byte[] newUnicodePassword = newQuotedPassword.getBytes("UTF-16LE");

      mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
          new BasicAttribute("unicodePwd", newUnicodePassword));
      mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
          new BasicAttribute("userAccountControl", Integer.toString(UF_NORMAL_ACCOUNT + UF_PASSWORD_EXPIRED)));

      // Perform the update
      // HashMap<String, Object> map = new HashMap<String, Object>();
      String username = (String) pluginParams.get("UserId");
      ctx.modifyAttributes(username, mods);

      System.out.println("Set password & updated userccountControl");
    }
    catch (NamingException e)
    {
      e.printStackTrace();
      System.out.println("change description failed" + e.getMessage());
    }
    catch (UnsupportedEncodingException e)
    {

      e.printStackTrace();
    }
    catch (IOException e)
    {

      e.printStackTrace();
    }
    return null;
  }

  /**
   * Gets the ldap context.
   *
   * @return the ldap context
   */
  public LdapContext getLdapContext()
  {

    try
    {
      Map<String, String> connectionConfiguration = null;
      connectionConfiguration = getConnectionConfig();
      // Reading the configuration details for logging into Active directory system
      // from the
      // connectionConfiguration.
      String contextFactory = connectionConfiguration.get("INITIALCONTEXTFACTORY");
      String password = connectionConfiguration.get("PASSWORD");
      String user = connectionConfiguration.get("USER");
      String sysnr = connectionConfiguration.get("SECURITY_AUTHENTICATION");
      String url = connectionConfiguration.get("PROVIDER_URL");
      logger.info(contextFactory);
      logger.info("ASHost" + contextFactory);

      logger.info(user);
      logger.info("USER" + user);
      logger.info(sysnr);
      logger.info("SYSNR" + sysnr);
      logger.info(url);
      logger.info("PROVIDER_URL" + url);
      logger.info("It is working normally");
      Hashtable<String, String> env = new Hashtable<String, String>();
      env.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
      env.put(Context.SECURITY_AUTHENTICATION, sysnr);
      env.put(Context.SECURITY_PRINCIPAL, user);// input user & password for access to ldap
      env.put(Context.SECURITY_CREDENTIALS, password);
      env.put(Context.PROVIDER_URL, url);
      System.out.println("Attempting to Connect...");

      ctx = new InitialLdapContext(env, null);
      System.out.println("Connection Successful.");
    }
    catch (NamingException nex)
    {
      System.out.println("LDAP Connection: FAILED");
      nex.printStackTrace();
    }
    return ctx;
  }

  /**
   * This method is to take the configuration details of Active Directory from a
   * configuration file. configuration parameters are: USER - which resembles the
   * userName, PASSWORD - which resembles the password,
   * 
   *
   * @return the connection config
   */
  private Map<String, String> getConnectionConfig()
  {
    try
    {
      Properties connectionProperty = new Properties();
      String configFile = "D:\\Jetty\\jetty-distribution-9.4.20.v20190813\\jetty-distribution-9.4.20.v20190813\\webapps\\PluginConfig\\ActiveDirectory.properties";
      FileReader fReader = null;
      fReader = new FileReader(configFile);
      try
      {
        connectionProperty.load(fReader);
      }
      catch (IOException e)
      {
        e.printStackTrace();
        logger.severe(e.getMessage());
      }
      hashMap.put("INITIALCONTEXTFACTORY", connectionProperty.getProperty("INITIAL_CONTEXT_FACTORY"));
      hashMap.put("USER", connectionProperty.getProperty("USER"));
      hashMap.put("PASSWORD", connectionProperty.getProperty("PASSWORD"));
      hashMap.put("SECURITY_AUTHENTICATION", connectionProperty.getProperty("SECURITY_AUTHENTICATION"));
      hashMap.put("PROVIDER_URL", connectionProperty.getProperty("PROVIDER_URL"));
      hashMap.put("EMAIL", connectionProperty.getProperty("EMAIL"));
      hashMap.put("PASSWORDEMAIL", connectionProperty.getProperty("PASSWORDEMAIL"));
      hashMap.put("SEARCH_BASE", connectionProperty.getProperty("SEARCH_BASE"));
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
      logger.severe(e.getMessage());
    }
    return hashMap;
  }

  /**
   * Geek password. This our Password generating method We have use static here,
   * so that we need not make any object for it
   * 
   * @return the string
   */
  static String geek_Password()
  {
    int MAX_LENGTH = 16;
    String DIGITS = "23456789";
    String LOCASE_CHARACTERS = "abcdefghjkmnpqrstuvwxyz";
    String UPCASE_CHARACTERS = "ABCDEFGHJKMNPQRSTUVWXYZ";
    String SYMBOLS = "@#$%=:?";
    String ALL = DIGITS + LOCASE_CHARACTERS + UPCASE_CHARACTERS + SYMBOLS;
    char[] upcaseArray = UPCASE_CHARACTERS.toCharArray();
    char[] locaseArray = LOCASE_CHARACTERS.toCharArray();
    char[] digitsArray = DIGITS.toCharArray();
    char[] symbolsArray = SYMBOLS.toCharArray();
    char[] allArray = ALL.toCharArray();
    Random r = new Random();

    StringBuilder sb = new StringBuilder();

    // get at least one lowercase letter
    sb.append(locaseArray[r.nextInt(locaseArray.length)]);

    // get at least one uppercase letter
    sb.append(upcaseArray[r.nextInt(upcaseArray.length)]);

    // get at least one digit
    sb.append(digitsArray[r.nextInt(digitsArray.length)]);

    // get at least one symbol
    sb.append(symbolsArray[r.nextInt(symbolsArray.length)]);

    // fill in remaining with random letters
    for (int i = 0; i < MAX_LENGTH - 4; i++)
    {
      sb.append(allArray[r.nextInt(allArray.length)]);
    }

    return sb.toString();
  }
  
  /**
   * The main method.
   *
   * @param args the arguments
   * @throws NamingException the naming exception
   */
  public static void main(String[] args)
  {
    System.out.println("hi");

  }

  

  public ResultsBlock createUser(Parameters parameters) throws NamingException
  {
    ResultsBlock result = null ;
    for (String client: parameters.getClients()) {
      for (String landscape: parameters.getEnvironmentsOfClientType(client, this.environmentTag)) {
        ClientContext clientContext = getClientContext(client);
        Attributes container = new BasicAttributes();
        container.put("objectClass","User");
        container.put("cn", parameters.getField("id"));
        container.put("sAMAccountName", parameters.getField("id"));
        container.put("mail", parameters.getField("email"));
        container.put("givenName", parameters.getField("first_name"));
        container.put("uid", parameters.getField("id"));
        container.put("sn", parameters.getField("last_name"));
        container.put("displayName", parameters.getField("first_name") + " " + parameters.getField("last_name"));
        container.put("description", parameters.getField("department"));
        container.put("userPrincipalName", parameters.getField("id"));
        container.put("accountExpires", parameters.getField("end_date"));
        // container.put("userpassword", );
        LdapContext context = clientContext.getEnvironmentConfiguration(landscape).getLdapContext();
        context.createSubcontext(getUserDN(parameters.getField("id")), container);
        context.close();
        return result;
      }
    }
    return result;
  }

  private ClientContext getClientContext(String client)
  {
    // TODO Auto-generated method stub
    return null;
  }

  public ResultsBlock validateParameters(Parameters parameters)
  {
    // TODO Auto-generated method stub
    return null;
  }

 }