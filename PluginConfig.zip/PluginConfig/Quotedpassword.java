 String quotedPassword = "\" + password + "\"";

                 char unicodePwd[] = quotedPassword.toCharArray();
			  byte pwdArray[] = new byte[unicodePwd.length * 2];
			       for (int i = 0; i < unicodePwd.length; i++)
			       {
			     pwdArray[i * 2 + 1] = (byte) (unicodePwd[i] >>> 8);
			     pwdArray[i * 2 + 0] = (byte) (unicodePwd[i] & 0xff);
			       } 